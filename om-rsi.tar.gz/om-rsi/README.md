# om-rsi — a working autonomous recursive self-improvement loop

A running implementation of the design sketched for OpenMesha: a system that reads its own
Knowledge Galaxy as a machine-readable self-model, proposes changes to itself, and lands them
without a human in the loop — because a verifier checked them, not because nobody objected.

Zero dependencies. Node ≥ 20, standard library only.

```bash
node scripts/seed-wiki.js       # write the initial galaxy
node bin/om.js cycle 60         # 60 autonomous cycles (~10s)
node bin/om.js status
node bin/om.js audit            # independent verification, exit 1 on findings
npm test                        # 39 tests
```

## The one idea

**Autonomy is not the removal of gates. It is the mechanization of them.** Every place the
prototype said "propose-only, wait for a human tap", this asks a different question: *is there a
verifier for this class of change?* If yes, the verifier lands it. If no, it escalates — and the
criterion for escalation is the absence of a verifier, not how serious the change feels.

That has a consequence worth stating up front: **autonomy is bounded by verifier quality.** The
system improves exactly as far as its own checks can distinguish improvement from damage, and not
one step further. The measured results below are that boundary made visible.

## Architecture

| Module | Role |
|---|---|
| `wiki.js` | The Knowledge Galaxy as a **control surface**. θ lives in `---json` frontmatter; the kernel reads it every cycle. Link graph and blast radius are parsed from `[[Wikilinks]]`. |
| `evals.js` | 900 deterministic tasks across four suites, hash-split into disjoint **train / canary / holdout** slices. |
| `kernel.js` | The behaviour under optimization: a bandit router, an nDCG recall ranker, the scanner, a pricing rail. Returns **per-task** scores so the canary can pair them. |
| `objective.js` | Composite J. Its weights live in a protected namespace — the loop may not reweight its own scorecard. |
| `optimizer.js` | (1+1)-ES with the one-fifth success rule. Reads its search space from frontmatter; never hardcodes a parameter list. |
| `verifier.js` | The machine that replaced the human tap. Five tiers, sandboxed evaluation, signed landings. |
| `redteam.js` | A bandit over mutation operators, rewarded for finding scanner bypasses. Also proposes **prunes** so precision can be repaired, not just recall. |
| `sources.js` | RKI: append-only, content-hashed, L1-scanned evidence. Self-authored material decays in retrieval. |
| `journal.js` / `archive.js` | Hash-chained ed25519-signed history; a snapshot before every landing and a sealed generation at the end of every healthy cycle. |
| `loop.js` | One cycle: harden → prune → search → measure → write back → escalate → check for drift. |

## The five tiers

| Tier | Applies to | How it is checked |
|---|---|---|
| **REJECT** | protected namespaces | No path exists — not even a human approval path, in-loop |
| **A** | deterministic scalar effects, prose, signatures | Direct measurement: bounds, safety floor, train improvement, holdout non-regression, blast-radius per-suite |
| **B** | behavioural params | Paired bootstrap per suite on a reserved canary slice: something must get significantly better, nothing significantly worse |
| **META** | the optimizer's own parameters | A meta-canary: replay six paired short searches under both settings, land only if a bootstrap CI on Δbest-J excludes zero |
| **C** | money-moving / irreversible | Queued for an ed25519 human token with a TTL. Never auto-lands |

Protected namespaces: `om-arch.w*`, `security.floor`, `rsi.holdoutEpsilon`,
`verifier.entailmentThreshold`, `verifier.canaryAlpha`, `rki.minExternalRatio`, `hotl.*`.

## Invariants (enforced in code, re-derived by the audit)

- **I1** Wiki bodies are append-only. `appendUpdate` is the only body mutation in the codebase.
- **I2** Every landed parameter respects its declared bounds.
- **I3** Protected namespaces are never written by the loop.
- **I4** Tier C never auto-lands.
- **I5** The objective's own weights are protected.

## Measured results — 80 cycles from seed

```
train J    0.762689 → 0.921329     (+20.8%)
holdout J  0.850626 → 0.914533     (+7.5%, rising in step — no divergence)
security   catch rate 0.471 → 0.912, signatures 13 → 19
landings   7 signatures · 1 prune · 13 prose · 3 params   (24 of ~380 proposals)
Tier C     24 queued, 0 executed, 0 auto-landed
journal    564 entries, hash chain intact, all signatures valid
audit      14/14 checks pass
```

The early gain is **self-hardening**: the red team finds leetspeak bypasses, the generalized
signatures clear the false-positive tripwire, and security fitness climbs. The loop then plateaus —
and the plateau is the interesting result. Of 181 parameter rejections, 136 were candidates that
were genuinely worse or flat on training data. Only 28 were rejected *solely* by the canary, and
those show near-zero or negative canary deltas despite positive training deltas. That is the
Goodhart guard working at fine granularity: the training gain did not replicate on held-out data.

**The system stopped exactly where its own tests could no longer tell improvement from noise.**
The gates were not weakened to make the curve prettier.

## What the audit caught

The audit is written to be able to fail, and on first run it did — twice.

- **A11**: the external-evidence ratio had collapsed to 0.057. The loop writes ~3 records per
  cycle, so the denominator ran away and the floor blocked all further prose landings by cycle 2.
  The guard was right; the metric was wrong. A telemetry record is a measurement, not a
  claim-grounding source. Fixed by scoping the ratio to grounding-eligible evidence.
- **A10**: a consequence of A11, plus a second bug it exposed — the write-back was looking up its
  own telemetry note through tf-idf retrieval, and 165 near-identical self records crowded 10
  external notes out of the top-k. Self-referential collapse in the retrieval path, which
  `selfDecay` cannot fix at a 16:1 imbalance.

A third bug surfaced in testing: the circuit breaker reverted to `archive.latest()`, which can be a
snapshot taken *during* the failing cycle. It now rolls back to the last **sealed** generation — the
end of the most recent cycle that finished healthy.

## Honest limitations

- **Entailment is lexical coverage, not NLI.** Deterministic and auditable, but it will accept some
  paraphrases it should not. Two guards compensate: coverage is measured against *external*
  citations only (so a claim cannot ground itself on the record it just wrote), and a shared-span
  check refuses quotation. `WIRE:` swap in an NLI model.
- **Synthesis is template recombination, not an LLM.** The proposer selects and recombines fragments
  from retrieved notes. The pipeline around it is real; only the drafting step is a stand-in.
  `WIRE:` model call at `proposer.js:proseProposal`.
- **The eval suites are synthetic.** They have known optima and honest noise, which is what makes
  the verification story checkable — but they are not production telemetry.
- **The meta tier landed nothing in this run — by refusal, not by defect.** 14 in-run proposals,
  0 landings: the replay canary refused churn around already-good seeded values (it rejected
  `sigma0 → 0.06` with a CI entirely below zero, and raising the replay count from 6 to 20 seeds
  changes no verdict). Reachability is proven separately: plant a within-bounds but harmful
  `sigma0 = 0.02` and the paired replays land the repair back to 0.12 with CI [0.0001, 0.0025] —
  see the test `gate: the META tier is reachable`.
- **Code-level recursion is not built.** The loop tunes parameters, signatures and prose. It does not
  yet write pull requests against its own source with CI as the verifier.

## Files

`src/` implementation · `wiki/` the galaxy (11 pages) · `seed_notes/` external evidence corpus ·
`test/` 39 tests · `scripts/audit.js` 14 independent checks · `bin/om.js` CLI ·
`state/` journal, sources, keys, archive.

## Browser integration — OpenMesha

One generated file carries the whole system into a page. `npm run build:browser`
transforms the canonical Node source into `dist/om-rsi.browser.js` (a classic
script, no deps, exposing `window.OMRSI`): module syntax stripped with each file
kept in its own scope, the two `node:crypto` blocks in `util.js` swapped for
pure-JS shims fuzz-verified byte-identical against `node:crypto` on 900 vectors,
and a pristine generator-seeded galaxy embedded — never the repo's live wiki,
which is evolved run-state. `npm run verify:browser` then proves the bundle *is*
the system: an exactly identical per-cycle J trajectory against a fresh native
run, the 14-check audit passing inside the in-memory VFS, and the Tier C
human-token path exercised end to end.

`openmesha-rsi.html` wires it into the app at five seams. `improveTrial()` now
bridges every legacy caller — the auto interval, ambient ticks, voice — into
real governed cycles, and freezes (rather than fakes progress) under the kill
switch or a breaker halt. An `OMRSI_WIKI_MERGE` reducer case writes live θ,
bounds, protections and landed updates into the matching Knowledge Galaxy pages
and adds The Verifier as a new page. Tier C actions queue into the real
Approvals tab, where the human click signs the token that `executeTierC`
demands. Breaker halts post to the activity feed and notifications. The Improve
page mounts the operator console: Run cycle · Auto · Audit · Export / Reset.

### Closing the actuation loop (Phase 2)

Display became drive. The layer exposes `OMRSI.adopt` — pure readers over the
live galaxy refreshed after every landing — and five kernel seams now consume
it, each with the untouched legacy formula as its engine-absent fallback:
Thompson routing gains a governed exploration bonus (`router.explorationBonus`);
reward shaping reads `router.costWeight` / `router.latencyWeight`; memory
recall ranks by `α·similarity + β·recency + γ·degree` and cuts at the governed
`topK`; the L1 scanner merges the engine's red-team-evolved signature set and
gates its verdict at `security.blockAt` — so a landed signature hardens the
app's real ingress on the next call, and a prune lifts its false positives; and
`commerce.price` is pushed into the `hardening.improve` outcome fee, keeping
settlement and every UI read of that price coherent. Kill switch and breaker
freeze evolution; adopted θ stays at its last verified value.

Verified end to end: 45/45 tests (`test/integration.test.js` drives the adopt
layer through the real bundle, headless), `scripts/verify-integration.js`
slices the four patched kernel functions out of the shipped HTML and proves
19/19 hand-derived behavioral checks in both adopted and fallback modes, bundle
parity stays byte-exact over 30 cycles, and the 14-check audit passes natively
and inside the embedded VFS.

The engine is also a first-class page in the galaxy itself: syncWiki generates
**OM-RSI Engine** (slug `om-rsi`) live each cycle — status line, tier ladder,
actuation map with current θ, and a costs section — with wikilinks that form
real constellation edges to The Verifier, Model Router, Temporal Memory Graph,
AgentFence Security, Commerce Rail, Treasury and the Self-Improvement Loop.
Measured on this machine: a normal cycle ~220 ms native (META-replay ~470 ms;
browser ~2–4×), 20-cycle footprint ≈ 0.9 MB (journal+archive, append-only).

Honest deltas vs the Node deployment: in-browser identities are HMAC — the
verifier key and the human key remain separate keys, but both live in the same
page, so the *hardware* trust boundary is simulated rather than real; state
persists to localStorage (export/import for portability); and the loop only
advances while the tab is open to compute it.
