---json
{
 "slug": "commerce",
 "title": "Commerce Rail",
 "sys": "commerce",
 "group": "commerce",
 "params": {
  "price": 3
 },
 "bounds": {
  "price": [
   0.5,
   14
  ]
 },
 "behavioral": [
  "price"
 ],
 "evals": [
  "commerce"
 ],
 "invariants": [
  "price changes never bypass the canary"
 ]
}
---
# Commerce Rail

Metered services priced per call. Demand falls exponentially in price with a segment-specific scale λ, so revenue p·d(p) is single-peaked and the suite score is realized revenue as a fraction of the achievable maximum. This is the cleanest optimum in the mesh and the easiest place to watch the search work.

Charging is gated by [[AgentFence Security]] on ingest and by [[Human-on-the-Loop]] on settlement — the loop may reprice, but it may not move money. See [[System Architecture]].