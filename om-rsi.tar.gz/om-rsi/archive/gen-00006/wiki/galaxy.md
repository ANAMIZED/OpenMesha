---json
{
 "slug": "galaxy",
 "title": "Knowledge Galaxy",
 "sys": "mem",
 "group": "intelligence",
 "params": {},
 "bounds": {},
 "behavioral": [],
 "evals": [],
 "invariants": [
  "prose is append-only",
  "frontmatter params are the live control surface"
 ]
}
---
# Knowledge Galaxy

The system's self-model — one page per subsystem, cross-linked into a navigable constellation. Unlike a documentation wiki, this one is **load-bearing**: the governed parameters θ live in each page's `---json` frontmatter, and the kernel reads them at the start of every cycle. Editing a page *is* editing the system.

Three fields make each page machine-usable:
- `params` / `bounds` — the writable surface and its legal range.
- `behavioral` — params whose effect is distributional, so changes must clear a canary rather than a single evaluation.
- `evals` — which suites cover this subsystem, so [[Verifier Stack]] can compute a blast radius from the link graph.

Prose is append-only. Diffs are proposed by [[Recursive Knowledge Improvement]] from cited sources and land only after entailment and contradiction checks. Edges are parsed straight from wikilinks; a change to any page pulls in the eval suites of every page it links to, in either direction. Cycle summaries write back here, which is what makes the loop recursive: the next proposer inherits this page's history as context.

See also [[Self-Improvement Loop]] and [[System Architecture]].