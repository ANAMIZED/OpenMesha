---json
{
 "slug": "hotl",
 "title": "Human-on-the-Loop",
 "sys": "sec",
 "group": "governance",
 "params": {
  "tokenTtlMinutes": 60,
  "breakerDrop": 0.02
 },
 "bounds": {
  "tokenTtlMinutes": [
   5,
   1440
  ],
  "breakerDrop": [
   0,
   1
  ]
 },
 "behavioral": [],
 "evals": [],
 "invariants": [
  "Tier C items require an ed25519 human token to execute"
 ]
}
---
# Human-on-the-Loop

The residual queue. In a fully autonomous mesh this is not where every change goes — it is where changes go **when no machine verifier exists for them**. Money movement, external commitments, anything irreversible outside the sandbox.

Approval is a signed artifact, not a click: the human key signs the change-set hash, the token expires after `tokenTtlMinutes`, and the signature is journalled with the action. The [[Verifier Stack]] refuses to execute a Tier C item without one. The kill switch lives here too — tripping it halts proposal and landing while reads stay open.

Protected by namespace: the loop cannot alter its own escalation policy.