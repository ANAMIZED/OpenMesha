---json
{
 "slug": "learning",
 "title": "Learning Curves",
 "sys": "improve",
 "group": "learning",
 "params": {},
 "bounds": {},
 "behavioral": [],
 "evals": [],
 "invariants": [
  "train and holdout are reported together, always"
 ]
}
---
# Learning Curves

Longitudinal J on the training split, the holdout, and the divergence between them. Rising train with flat-or-rising holdout is improvement. Rising train with falling holdout is Goodharting, and the audit treats a sustained gap as a finding rather than a curiosity.

Written back each cycle by the [[Self-Improvement Loop]]; the underlying policy lives in [[Model Router]].

**Cycle 1 · 2026-08-20T22:05:24.382Z** — Method note — Expansion factors are typically small, near 1.1, and one-fifth success rule adapts the step size from. Measured this cycle: training J 0.762689 against holdout J 0.850626, with sigma 0.086700 at acceptance 0.000000. [cites: 7a3395b9de, d9572c7854]