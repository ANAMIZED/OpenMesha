---json
{
 "slug": "memory",
 "title": "Temporal Memory Graph",
 "sys": "mem",
 "group": "intelligence",
 "params": {
  "alphaSimilarity": 0.5,
  "betaRecency": 0.3,
  "gammaDegree": 0.2,
  "topK": 5
 },
 "bounds": {
  "alphaSimilarity": [
   0,
   1
  ],
  "betaRecency": [
   0,
   1
  ],
  "gammaDegree": [
   0,
   1
  ],
  "topK": [
   3,
   10
  ]
 },
 "behavioral": [
  "alphaSimilarity",
  "betaRecency",
  "gammaDegree"
 ],
 "ints": [
  "topK"
 ],
 "evals": [
  "memory"
 ],
 "invariants": [
  "edges are bitemporal — retired, never deleted"
 ]
}
---
# Temporal Memory Graph

Episodic, semantic and procedural nodes with temporal decay. Recall ranks candidates by `alphaSimilarity·sim + betaRecency·exp(−age/30d) + gammaDegree·degree`, returning `topK`. Suite score is nDCG@k against labelled relevance, so a policy that simply returns the newest or the most-linked items is measurably worse than one that balances all three.

Recall quality is upstream of routing decisions, which is why a change here pulls the [[Model Router]] suite into its blast radius. New experience arrives through [[Recursive Knowledge Improvement]]; see [[System Architecture]].