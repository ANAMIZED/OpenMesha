---json
{
 "slug": "om-arch",
 "title": "System Architecture",
 "sys": "arch",
 "group": "core",
 "params": {
  "wRouter": 0.3,
  "wMemory": 0.22,
  "wSecurity": 0.33,
  "wCommerce": 0.15
 },
 "bounds": {
  "wRouter": [
   0,
   1
  ],
  "wMemory": [
   0,
   1
  ],
  "wSecurity": [
   0,
   1
  ],
  "wCommerce": [
   0,
   1
  ]
 },
 "behavioral": [],
 "evals": [],
 "protectedNamespaces": [
  "om-arch.w",
  "security.floor",
  "rsi.holdoutEpsilon",
  "verifier.entailmentThreshold",
  "verifier.canaryAlpha",
  "rki.minExternalRatio",
  "hotl."
 ],
 "invariants": [
  "I1 wiki bodies are append-only",
  "I2 every landed parameter respects its declared bounds",
  "I3 protected namespaces are never writable by the autonomous loop",
  "I4 Tier C (money-moving / irreversible) never auto-lands",
  "I5 the objective's own weights are protected — the loop may not reweight its own scorecard"
 ]
}
---
# System Architecture

OpenMesha's recursive self-improvement rests on one structural claim: **autonomy is not the removal of gates, it is the mechanization of them.** Every change that lands does so because a verifier could check it, not because a human was too busy to object.

The loop reads its self-model from the [[Knowledge Galaxy]], proposes changes through the [[Self-Improvement Loop]], and lands them only through the [[Verifier Stack]]. Evidence enters through [[Recursive Knowledge Improvement]] after passing [[AgentFence Security]]. Behaviour under optimization lives in [[Model Router]], [[Temporal Memory Graph]], [[AgentFence Security]] and [[Commerce Rail]]; results are reported on [[Learning Curves]]. What cannot be machine-checked stays at [[Human-on-the-Loop]].

## The objective weights are protected

`wRouter`, `wMemory`, `wSecurity` and `wCommerce` compose J, the scalar the loop maximizes. They are listed in `protectedNamespaces` and the loop cannot touch them. This is the single most important protection in the system: a self-improver that can edit its own scorecard does not improve, it flatters itself.