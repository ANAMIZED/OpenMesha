---json
{
 "slug": "rki",
 "title": "Recursive Knowledge Improvement",
 "sys": "improve",
 "group": "learning",
 "params": {
  "selfDecay": 0.6,
  "topKSources": 5,
  "minExternalRatio": 0.4
 },
 "bounds": {
  "selfDecay": [
   0.3,
   0.95
  ],
  "topKSources": [
   3,
   10
  ],
  "minExternalRatio": [
   0,
   1
  ]
 },
 "behavioral": [],
 "ints": [
  "topKSources"
 ],
 "evals": [],
 "invariants": [
  "sources are append-only and content-hashed",
  "quarantined sources are never citable",
  "self-authored sources decay in retrieval weight by generation"
 ]
}
---
# Recursive Knowledge Improvement

Raw inputs — external notes, tool output, cycle telemetry — are ingested as **append-only, content-hashed sources**. Nothing is overwritten; corrections supersede. Every ingest passes L1 scan from [[AgentFence Security]] first: flagged text is stored quarantined and can never be cited, which is the answer to memory poisoning once the corpus starts driving behaviour.

## Why self-authored knowledge decays

A loop that writes its own reference material and then cites it converges on its own priors — the corpus stops carrying information about the world and starts carrying information about the model. Two defenses: `selfDecay` down-weights self-origin sources by generation at retrieval time, and `minExternalRatio` (protected) is a floor on the share of citable sources that came from outside. Below the floor, self-cited prose diffs are refused outright.

Synthesis produces propose-only diffs into the [[Knowledge Galaxy]] and observations for the [[Temporal Memory Graph]].