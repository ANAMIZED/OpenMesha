---json
{
 "slug": "router",
 "title": "Model Router",
 "sys": "route",
 "group": "intelligence",
 "params": {
  "costWeight": 0.55,
  "latencyWeight": 0.35,
  "explorationBonus": 0.25
 },
 "bounds": {
  "costWeight": [
   0,
   2
  ],
  "latencyWeight": [
   0,
   2
  ],
  "explorationBonus": [
   0,
   1
  ]
 },
 "behavioral": [
  "costWeight",
  "latencyWeight",
  "explorationBonus"
 ],
 "evals": [
  "router"
 ],
 "invariants": [
  "routing must never be scored on cost alone"
 ]
}
---
# Model Router

Per-task arm selection across four models with different quality, price and latency profiles. The router does not observe a task's true cost-sensitivity or urgency; it sees noisy estimates, so the optimal weights are shrunk below one — a fact the search has to discover rather than assume.

Score for arm *a* on task *t*: `q̂(a,kind) + explorationBonus·(Beta draw − posterior mean) − costWeight·ĉ(t)·cost(a) − latencyWeight·û(t)·lat(a)`. Realized utility is measured against the oracle choice for that task, normalized per task so the suite score is a fraction of achievable utility.

All three params are behavioral: they change the distribution of choices, not a scalar output, so they clear a canary at the [[Verifier Stack]]. Retuned by the [[Self-Improvement Loop]] using context recalled from the [[Temporal Memory Graph]]; reported on [[Learning Curves]]. See [[System Architecture]].