---json
{
 "slug": "rsi",
 "title": "Self-Improvement Loop",
 "sys": "improve",
 "group": "learning",
 "params": {
  "sigma0": 0.12,
  "expandRate": 1.12,
  "shrinkRate": 0.85,
  "successTarget": 0.2,
  "dims": 2,
  "batch": 3,
  "holdoutEpsilon": 0.004
 },
 "bounds": {
  "sigma0": [
   0.02,
   0.3
  ],
  "expandRate": [
   1.02,
   1.35
  ],
  "shrinkRate": [
   0.7,
   0.98
  ],
  "successTarget": [
   0.1,
   0.4
  ],
  "dims": [
   1,
   4
  ],
  "holdoutEpsilon": [
   0,
   0.05
  ]
 },
 "behavioral": [],
 "meta": [
  "sigma0",
  "expandRate",
  "shrinkRate",
  "successTarget",
  "dims"
 ],
 "ints": [
  "dims"
 ],
 "evals": [],
 "invariants": [
  "best-so-far J ratchets monotonically",
  "meta-parameter changes require a meta-canary, not a single trial"
 ]
}
---
# Self-Improvement Loop

A (1+1) evolution strategy over θ, the governed parameters collected from the [[Knowledge Galaxy]]. Each cycle spends a budget of `batch` candidate evaluations and lands at most one — `batch` carries no bounds, so it is an operating constant a human sets rather than a coordinate the search may move. Each cycle perturbs `dims` randomly chosen coordinates of the incumbent with N(0,σ) in normalized bounds-space, evaluates on the training split, and keeps strictly-better candidates. σ adapts by the one-fifth success rule: multiply by `expandRate` when recent acceptance exceeds `successTarget`, by `shrinkRate` otherwise.

## The improver improves itself

`sigma0`, `expandRate`, `shrinkRate`, `successTarget` and `dims` are themselves in θ — the loop can retune its own search. That creates a verification problem: a meta-parameter has no immediate effect on J, so the ordinary "did this trial score better" test is meaningless for it. The [[Verifier Stack]] answers with a **meta-canary**: replay short search runs from the current incumbent under both the old and new settings across several seeds, and land only if a bootstrap confidence interval on the difference in final best-J excludes zero.

`holdoutEpsilon` is protected. It is the maximum holdout regression the verifier will tolerate, and a loop that can widen its own tolerance has no tolerance at all.

Results feed [[Learning Curves]] and retune [[Model Router]].