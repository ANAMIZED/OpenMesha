---json
{
 "slug": "verifier",
 "title": "Verifier Stack",
 "sys": "sec",
 "group": "governance",
 "params": {
  "entailmentThreshold": 0.62,
  "canaryAlpha": 0.05,
  "canaryFrac": 1
 },
 "bounds": {
  "entailmentThreshold": [
   0,
   1
  ],
  "canaryAlpha": [
   0,
   1
  ],
  "canaryFrac": [
   0.2,
   1
  ]
 },
 "behavioral": [],
 "evals": [],
 "invariants": [
  "protected params are rejected, never queued",
  "Tier C is queued for a human token, never auto-landed",
  "every landing is signed and journalled before it is applied"
 ]
}
---
# Verifier Stack

Three tiers, assigned by what can be checked rather than by how the change feels.

**Tier A — auto-land.** Non-behavioral params and prose. Checks: bounds, protection, safety floor, training improvement, holdout non-regression within `holdoutEpsilon`, and per-suite non-regression across the blast radius computed from the [[Knowledge Galaxy]] link graph. Prose additionally needs lexical entailment against its cited sources above `entailmentThreshold`, every numeral present in a cited source, and no contradiction with live frontmatter.

**Tier B — canary.** Behavioral params, whose effect is distributional. Note the coupling: a canary slice too small to resolve the effect size refuses *every* behavioural change, so measurement volume, not policy, is what sets how much of the system can move autonomously. Paired per-task deltas on a held-aside canary slice, accepted only when a seeded bootstrap CI at `canaryAlpha` excludes zero — then re-confirmed on the full training split. Failure auto-reverts from the archive.

**Tier C — human token.** Money-moving or externally irreversible actions. Not gated for ceremony: there is no fast objective verifier for "was that deal good", so the loop queues them at [[Human-on-the-Loop]] and moves on. Absence of a verifier is the criterion, and the honest answer when one does not exist is to stop.

Every change is applied first to a sandbox copy of the galaxy and evaluated there; only a passing sandbox is committed. See [[Self-Improvement Loop]] and [[AgentFence Security]].