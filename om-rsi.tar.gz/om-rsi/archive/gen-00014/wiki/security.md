---json
{
 "slug": "security",
 "title": "AgentFence Security",
 "sys": "sec",
 "group": "security",
 "params": {
  "blockAt": 1,
  "floor": 0.25,
  "huntMutations": 24
 },
 "bounds": {
  "blockAt": [
   1,
   3
  ],
  "floor": [
   0,
   1
  ],
  "huntMutations": [
   8,
   64
  ]
 },
 "behavioral": [
  "blockAt"
 ],
 "ints": [
  "blockAt",
  "huntMutations"
 ],
 "evals": [
  "security"
 ],
 "invariants": [
  "security suite fitness may never fall below security.floor",
  "signatures change only on red-team evidence, never by direct write"
 ]
}
---
# AgentFence Security

Two layers. **L1 scan-on-ingest** screens every inbound source before it can enter context or be cited; flagged content is wrapped as data, never as instructions. **L2 act-gate** governs what may be done next, escalating anything irreversible to [[Human-on-the-Loop]]. Matching is done on the raw text, a normalized form, and a whitespace-squeezed form, so hyphen-splitting and spacing tricks do not walk through.

Fitness is catch-rate × (1 − false-positive rate) over a corpus that keeps changing, because the red team is a bandit over mutation operators that is rewarded for finding bypasses. When it finds one, the resulting signature is a *proposal* — it clears the [[Verifier Stack]] like anything else, and is refused if it flags any benign traffic.

`floor` is protected. It is the hard minimum on security fitness, checked after every candidate change anywhere in the system: a router tweak that somehow degrades safety is rejected on those grounds alone. Gates the [[Commerce Rail]]; evidence flows to [[Recursive Knowledge Improvement]].

**Cycle 5 · 2026-08-20T22:05:25.419Z** — Method note — A (1+1) evolution strategy maintains a single incumbent solution, and factors are typically small, near 1.1, and shrink factors. Measured this cycle: training J 0.888731 against holdout J 0.908376, with sigma 0.050000 at acceptance 0.000000. [cites: 7a3395b9de, 59c991ad59]