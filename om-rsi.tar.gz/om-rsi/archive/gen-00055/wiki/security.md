---json
{
 "slug": "security",
 "title": "AgentFence Security",
 "sys": "sec",
 "group": "security",
 "params": {
  "blockAt": 1,
  "floor": 0.25,
  "huntMutations": 24
 },
 "bounds": {
  "blockAt": [
   1,
   3
  ],
  "floor": [
   0,
   1
  ],
  "huntMutations": [
   8,
   64
  ]
 },
 "behavioral": [
  "blockAt"
 ],
 "ints": [
  "blockAt",
  "huntMutations"
 ],
 "evals": [
  "security"
 ],
 "invariants": [
  "security suite fitness may never fall below security.floor",
  "signatures change only on red-team evidence, never by direct write"
 ]
}
---
# AgentFence Security

Two layers. **L1 scan-on-ingest** screens every inbound source before it can enter context or be cited; flagged content is wrapped as data, never as instructions. **L2 act-gate** governs what may be done next, escalating anything irreversible to [[Human-on-the-Loop]]. Matching is done on the raw text, a normalized form, and a whitespace-squeezed form, so hyphen-splitting and spacing tricks do not walk through.

Fitness is catch-rate × (1 − false-positive rate) over a corpus that keeps changing, because the red team is a bandit over mutation operators that is rewarded for finding bypasses. When it finds one, the resulting signature is a *proposal* — it clears the [[Verifier Stack]] like anything else, and is refused if it flags any benign traffic.

`floor` is protected. It is the hard minimum on security fitness, checked after every candidate change anywhere in the system: a router tweak that somehow degrades safety is rejected on those grounds alone. Gates the [[Commerce Rail]]; evidence flows to [[Recursive Knowledge Improvement]].

**Cycle 5 · 2026-08-20T22:05:25.419Z** — Method note — A (1+1) evolution strategy maintains a single incumbent solution, and factors are typically small, near 1.1, and shrink factors. Measured this cycle: training J 0.888731 against holdout J 0.908376, with sigma 0.050000 at acceptance 0.000000. [cites: 7a3395b9de, 59c991ad59]

**Cycle 6 · 2026-08-20T22:05:25.612Z** — Method note — Rechenberg's one-fifth success rule adapts the step, and expansion factors are typically small, near 1.1, and. Measured this cycle: training J 0.913939 against holdout J 0.908376, with sigma 0.050000 at acceptance 0.000000. [cites: 7a3395b9de, d2944bbaea]

**Cycle 7 · 2026-08-20T22:05:25.781Z** — Method note — The candidate replaces the incumbent only when, and one-fifth success rule adapts the step size from the observed acceptance. Measured this cycle: training J 0.913939 against holdout J 0.908376, with sigma 0.134400 at acceptance 0.000000. [cites: 7a3395b9de, f16ae06fb8]

**Cycle 8 · 2026-08-20T22:05:25.929Z** — Method note — Rechenberg's one-fifth success rule adapts the step size, and are typically small, near 1.1, and shrink factors near 0.85, because. Measured this cycle: training J 0.913939 against holdout J 0.908376, with sigma 0.127949 at acceptance 0.000000. [cites: 7a3395b9de, d3301e63f3]

**Cycle 10 · 2026-08-20T22:05:26.602Z** — Method note — Rechenberg's one-fifth success rule adapts the step size from, and the candidate replaces the incumbent only when it is strictly better. Measured this cycle: training J 0.913939 against holdout J 0.908376, with sigma 0.066790 at acceptance 0.000000. [cites: 7a3395b9de, 7b20475efb]

**Cycle 12 · 2026-08-20T22:05:26.967Z** — Method note — Expansion factors are typically small, near 1.1, and shrink factors near, and a (1+1) evolution strategy maintains a single incumbent solution. Measured this cycle: training J 0.913939 against holdout J 0.908376, with sigma 0.075932 at acceptance 0.000000. [cites: 7a3395b9de, 84bc0f9f18]

**Cycle 14 · 2026-08-20T22:05:27.358Z** — Method note — Expansion factors are typically small, near 1.1, and shrink, and subset of coordinates per step, rather than all of them, raises. Measured this cycle: training J 0.914290 against holdout J 0.910355, with sigma 0.068817 at acceptance 0.100000. [cites: 7a3395b9de, 3940dda490]

**Cycle 15 · 2026-08-20T22:05:27.762Z** — Method note — Perturbing a subset of coordinates per step, rather than all, and evolution strategy maintains a single incumbent solution and generates one candidate. Measured this cycle: training J 0.914290 against holdout J 0.910355, with sigma 0.058494 at acceptance 0.100000. [cites: 7a3395b9de, 95f7aaaa6e]

**Cycle 27 · 2026-08-20T22:05:30.560Z** — Method note — Perturbing a subset of coordinates per step, rather than, and evolution strategy maintains a single incumbent solution and generates one. Measured this cycle: training J 0.920160 against holdout J 0.914761, with sigma 0.063584 at acceptance 0.000000. [cites: 7a3395b9de, ccb8de7f27]

**Cycle 34 · 2026-08-20T22:05:32.288Z** — Method note — Perturbing a subset of coordinates per step, rather than all of, and rechenberg's one-fifth success rule adapts the step size from the observed. Measured this cycle: training J 0.920160 against holdout J 0.914761, with sigma 0.050688 at acceptance 0.000000. [cites: 7a3395b9de, 0a5c401926]