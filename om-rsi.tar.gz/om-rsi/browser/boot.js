/* ── om-rsi boot: engine lifecycle + host-app glue + operator console ──────
   Runs inside the bundle IIFE with every engine symbol in scope. Exposes
   window.OMRSI. Works headless (no document) for the Node parity harness. */

const ROOT = "/om";
const MAP = { "om-arch": "om-arch", router: "router", memory: "memory", security: "security",
  commerce: "commerce", rki: "rki", hotl: "hotl", learning: "learning",
  rsi: "improve", galaxy: "wiki-galaxy", verifier: "verifier" };

const O = {
  ready: false, busy: false, autoOn: false, ctx: null,
  bestJ: 0, lastRec: null, lastCycleTs: 0, feed: [], lastAudit: null,
  el: null, listeners: [], persistOK: false, sentQids: null, lastMergeHash: "",
};

const nowMs = () => Date.now();
const hasDoc = () => typeof document !== "undefined" && document && document.createElement;
const disp = (a) => { try { if (typeof window !== "undefined" && window.__OM_DISPATCH) { window.__OM_DISPATCH(a); return true; } } catch (e) {} return false; };
const pushFeed = (kind, text) => { O.feed.unshift({ kind, text, ts: nowMs() }); if (O.feed.length > 12) O.feed.pop(); };

/* ── persistence (guarded — degrades to in-memory) ───────────────────────── */
const LS_KEY = "omrsi:vfs:v1";
function vfsSnapshot() {
  const out = {};
  for (const [k, v] of __VFS.entries()) if (k === ROOT || k.startsWith(ROOT + "/")) out[k] = v.t === "f" ? v.data : null;
  return out;
}
function vfsRestore(obj) {
  for (const [k, data] of Object.entries(obj)) { if (data === null) { if (!__VFS.has(k)) __VFS.set(k, { t: "d" }); } else fs.writeFileSync(k, data); }
}
function persistSave() {
  try { if (typeof localStorage === "undefined") return; localStorage.setItem(LS_KEY, JSON.stringify(vfsSnapshot())); O.persistOK = true; }
  catch (e) { O.persistOK = false; }
}
function persistLoad() {
  try { if (typeof localStorage === "undefined") return false;
    const raw = localStorage.getItem(LS_KEY); if (!raw) return false;
    vfsRestore(JSON.parse(raw)); return fs.existsSync(ROOT + "/wiki"); } catch (e) { return false; }
}

/* ── seed + init ─────────────────────────────────────────────────────────── */
function seedVfs() {
  fs.mkdirSync(ROOT + "/wiki", { recursive: true });
  fs.mkdirSync(ROOT + "/seed_notes", { recursive: true });
  for (const [n, body] of Object.entries(__SEED.wiki)) fs.writeFileSync(ROOT + "/wiki/" + n, body);
  for (const [n, body] of Object.entries(__SEED.notes)) fs.writeFileSync(ROOT + "/seed_notes/" + n, body);
  fs.mkdirSync(ROOT + "/src", { recursive: true });
  for (const [n, body] of Object.entries(__SEED.src)) fs.writeFileSync(ROOT + "/src/" + n, body);
}
function loadSent() { try { return new Set(JSON.parse(fs.readFileSync(ROOT + "/state/hotl-sent.json", "utf8"))); } catch (e) { return new Set(); } }
function saveSent() { try { fs.writeFileSync(ROOT + "/state/hotl-sent.json", JSON.stringify([...O.sentQids])); } catch (e) {} }

function init() {
  if (O.ready) return status();
  const restored = persistLoad();
  if (!fs.existsSync(ROOT + "/wiki")) seedVfs();
  O.ctx = makeContext(ROOT);
  O.sentQids = loadSent();
  const st = loadState(O.ctx);
  O.bestJ = st.history.reduce((m, h) => Math.max(m, h.trainJ), 0);
  O.lastRec = st.history[st.history.length - 1] || null;
  O.ready = true;
  pushFeed("boot", (restored ? "state restored · cycle " + st.cycle : "fresh galaxy seeded") + " · " + O.ctx.scanner.count() + " signatures");
  syncWiki(true); render(); emit();
  return status();
}

/* ── one governed cycle + host propagation ───────────────────────────────── */
function runOne() {
  if (!O.ready) init();
  const st0 = loadState(O.ctx);
  if (st0.halted) { render(); return { halted: true, reason: st0.haltReason }; }
  if (O.busy) return { busy: true };
  O.busy = true;
  let r;
  try { r = runCycle(O.ctx); } finally { O.busy = false; }
  O.lastRec = r.rec; O.lastCycleTs = nowMs();
  if (r.rec.trainJ > O.bestJ) O.bestJ = r.rec.trainJ;
  const lands = [...(r.results.param?.landed || []), ...(r.results.signature?.landed || []), ...(r.results.prose?.landed || [])];
  for (const L of lands) {
    const opTxt = L.op.kind === "param" ? L.op.slug + "." + L.op.key + " → " + L.op.value
      : L.op.kind === "prose" ? "grounded note → " + L.op.slug
      : L.op.kind === "signature-prune" ? "pruned /" + L.op.sig + "/" : "signature /" + String(L.op.sig).slice(0, 24) + "/";
    pushFeed("land", "tier " + L.tier + " · " + opTxt);
    disp({ type: "ACT", ev: { kind: "improve", text: "OM-RSI landed · tier " + L.tier + " · " + opTxt } });
  }
  const rej = (r.results.param?.rejected || []).length + (r.results.signature?.rejected || []).length + (r.results.prose?.rejected?.length || 0);
  if (!lands.length && rej) {
    const first = (r.results.param?.rejected || [])[0] || (r.results.prose?.rejected || [])[0];
    const why = first ? (first.checks.find(c => !c.ok) || {}).name : "no candidate";
    pushFeed("rej", "cycle " + r.cycle + " · " + rej + " refused" + (why ? " · " + why : ""));
  }
  for (const q of (r.results.tierC?.queued || [])) {
    if (O.sentQids.has(q.id)) continue;
    O.sentQids.add(q.id); saveSent();
    pushFeed("tierC", "queued · " + q.description + " · $" + q.amount);
    disp({ type: "ADD_HOTL", item: { action: "OM-RSI Tier C · " + q.description, amount: q.amount, kind: "omrsi-tierC", risk: "high", qid: q.id } });
    disp({ type: "NOTIFY", n: { kind: "hotl", text: "OM-RSI escalated a Tier C action — no fast verifier exists" } });
  }
  if (r.halted) {
    pushFeed("halt", r.haltReason);
    disp({ type: "ACT", ev: { kind: "security", text: "⛔ OM-RSI circuit breaker: " + r.haltReason + " — reverted to last sealed generation" } });
    disp({ type: "NOTIFY", n: { kind: "security", text: "OM-RSI halted itself: " + r.haltReason } });
  }
  syncWiki(); persistSave(); render(); emit();
  return r;
}
function cycle(n) { const out = []; for (let i = 0; i < (n || 1); i++) { const r = runOne(); out.push(r); if (r.halted || r.busy) break; } return out; }

/* ── galaxy write-back: governed sections + the Verifier page ────────────── */
function govSection(p, w) {
  const rows = Object.entries(p.params || {}).map(([k, v]) => {
    const b = (p.bounds || {})[k] || ["·", "·"];
    return "`" + p.slug + "." + k + "` = **" + v + "** ∈ [" + b[0] + ", " + b[1] + "]" + (w.isProtected(p.slug, k) ? " 🔒" : "");
  });
  const ups = (p.body.match(/\*\*[A-Za-z-]+ · [0-9T:.\-Z]+\*\* — [^\n]+/g) || []).slice(-2);
  return "Live θ, read by the kernel every cycle — changed only through the tiered verifier:\n\n" + rows.join(" · ") +
    (p.evals && p.evals.length ? "\n\nMeasured by: " + p.evals.join(", ") + "." : "") +
    (ups.length ? "\n\n" + ups.join("\n\n") : "");
}
function syncWiki(force) {
  if (!O.ready) return;
  const w = new Wiki(O.ctx.wikiDir);
  const attach = {}, pages = [];
  for (const p of Object.values(w.pages)) {
    const target = MAP[p.slug]; if (!target) continue;
    if (p.slug === "verifier") {
      pages.push({ slug: "verifier", title: "The Verifier", group: "core", sys: "improve", tags: ["verifier", "tiers", "gates"],
        body: p.body + "\n\n" + govSection(p, w) });
    } else attach[target] = govSection(p, w);
  }
  const h = sha256(stableStringify({ attach, pages }));
  if (!force && h === O.lastMergeHash) return;
  O.lastMergeHash = h;
  disp({ type: "OMRSI_WIKI_MERGE", attach, pages });
}

/* ── the legacy improveTrial bridge ──────────────────────────────────────── */
function normOf(w, full) {
  const d = thetaSpec(w).find(x => x.full === full);
  return d ? +((d.value - d.lo) / (d.hi - d.lo || 1)).toFixed(3) : 0.5;
}
function mapRec(rec, frozen) {
  const w = new Wiki(O.ctx.wikiDir);
  return { trial: rec ? rec.cycle : 0, best: +O.bestJ.toFixed(3), candidate: rec ? +rec.trainJ.toFixed(3) : +O.bestJ.toFixed(3),
    x: normOf(w, "router.costWeight"), y: normOf(w, "memory.alphaSimilarity"),
    accepted: !frozen && !!rec && rec.landed > 0, sigma: rec ? +rec.sigma.toFixed(3) : 0.12, halted: !!frozen };
}
function bridgeTrial(killed) {
  if (!O.ready || O.busy) return null;                      // legacy path until the engine is up
  const st = loadState(O.ctx);
  if (killed || st.halted) return mapRec(O.lastRec, true);   // frozen: nothing advances under kill/halt
  if (nowMs() - O.lastCycleTs < 1100) { const m = mapRec(O.lastRec, false); m.accepted = false; return m; }
  const r = runOne();
  return mapRec(r.rec || O.lastRec, !!r.halted);
}

/* ── Tier C: the human key lives here, behind the click ──────────────────── */
function approveTierC(qid, approve) {
  if (!O.ready) return { ok: false, error: "engine not ready" };
  if (approve === undefined) approve = true;
  const st = loadState(O.ctx);
  const i = (st.tierC || []).findIndex(x => x.id === qid);
  if (i < 0) return { ok: false, error: "unknown or already-resolved item " + qid };
  const item = st.tierC[i];
  st.tierC.splice(i, 1); saveState(O.ctx, st);
  if (!approve) {
    O.ctx.journal.append({ type: "reject.tierC", id: item.id, cycle: st.cycle }, O.ctx.keys);
    pushFeed("tierC", "rejected by human · " + item.description);
    persistSave(); render(); emit();
    return { ok: true, rejected: item.id };
  }
  const r = O.ctx.verifier.executeTierC(item, { sig: O.ctx.humanKeys.sign(item.id), issuedAt: nowMs() });
  pushFeed("tierC", (r.ok ? "executed under human token · " : "refused · " + (r.reason || "") + " · ") + item.description);
  persistSave(); render(); emit();
  return r;
}

/* ── audit, status, control ──────────────────────────────────────────────── */
function audit() {
  if (!O.ready) init();
  try { O.lastAudit = runAudit(ROOT); }
  catch (e) { O.lastAudit = { rows: [], failures: [{ id: "A0", name: "audit crashed", detail: String(e) }] }; }
  const f = O.lastAudit.failures.length;
  pushFeed("audit", f === 0 ? "all " + O.lastAudit.rows.length + " checks passed" : f + " finding(s)");
  render(); emit();
  return O.lastAudit;
}
function status() {
  const st = O.ready ? loadState(O.ctx) : { cycle: 0, halted: false, tierC: [] };
  const r = O.lastRec || {};
  return { ready: O.ready, cycle: st.cycle, halted: !!st.halted, haltReason: st.haltReason || null,
    trainJ: r.trainJ ?? null, holdoutJ: r.holdoutJ ?? null, bestJ: O.bestJ || null, sigma: r.sigma ?? null,
    catchRate: r.catchRate ?? null, fp: r.fp ?? null, signatures: O.ready ? O.ctx.scanner.count() : 0,
    tierCQueued: (st.tierC || []).length, landedTotal: (st.history || []).reduce((a, h) => a + (h.landed || 0), 0),
    persist: O.persistOK, auto: O.autoOn };
}
function auto(on) {
  O.autoOn = on === undefined ? !O.autoOn : !!on;
  const tick = () => { if (!O.autoOn) return;
    const st = loadState(O.ctx); if (st.halted) { O.autoOn = false; render(); return; }
    runOne(); setTimeout(tick, 1400); };
  if (O.autoOn && O.ready) setTimeout(tick, 10);
  render(); return O.autoOn;
}
function resume() {           // a human control, mirrored by `om resume` in the CLI
  if (!O.ready) return;
  const st = loadState(O.ctx); st.halted = false; st.haltReason = null; saveState(O.ctx, st);
  O.ctx.journal.append({ type: "resume", by: "human-console", ts: nowMs() }, O.ctx.keys);
  pushFeed("boot", "resumed by human after halt");
  persistSave(); render(); emit();
}
function exportState() {
  const json = JSON.stringify({ v: 1, exported: new Date().toISOString(), vfs: vfsSnapshot() });
  if (hasDoc()) { const b = new Blob([json], { type: "application/json" }); const a = document.createElement("a");
    a.href = URL.createObjectURL(b); a.download = "omrsi-state.json"; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 2000); }
  return json;
}
function importState(json) {
  const o = typeof json === "string" ? JSON.parse(json) : json;
  fs.rmSync(ROOT, { recursive: true, force: true });
  vfsRestore(o.vfs); O.ready = false; return init();
}
function reset() {
  fs.rmSync(ROOT, { recursive: true, force: true });
  try { if (typeof localStorage !== "undefined") localStorage.removeItem(LS_KEY); } catch (e) {}
  O.ready = false; O.bestJ = 0; O.lastRec = null; O.feed = []; O.lastAudit = null; O.lastMergeHash = "";
  return init();
}
function emit() { for (const cb of O.listeners) { try { cb(status()); } catch (e) {} } }

/* ── operator console (plain DOM, host theme tokens) ─────────────────────── */
function theme() {
  const T = (typeof window !== "undefined" && window.__OM_C) || {};
  return { panel: T.panel2 || "#0f141d", line: T.line || "#1a222e", ink: T.ink || "#e8eef5", ink2: T.ink2 || "#93a2b6",
    ink3: T.ink3 || "#5c6a80", mono: T.mono || "ui-monospace,Menlo,monospace", good: T.good || "#3ecf8e",
    bad: T.bad || "#ff6b6b", gold: T.gold || "#f5c451", improve: T.improve || "#b48cff", route: T.route || "#5aa9ff" };
}
function esc(s) { return String(s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c])); }
function render() {
  if (!O.el || !hasDoc()) return;
  const C = theme(), s = status();
  const fmt = (x, d) => x == null ? "—" : (+x).toFixed(d === undefined ? 4 : d);
  const btn = (id, label, color, title) => '<button data-omrsi="' + id + '" title="' + esc(title || "") + '" style="cursor:pointer;background:transparent;border:1px solid ' + C.line + ';color:' + (color || C.ink2) + ';font:600 11px ' + C.mono + ';padding:5px 10px;border-radius:7px">' + label + "</button>";
  const kv = (l, v, c) => '<div style="display:flex;justify-content:space-between;padding:4px 0;border-top:1px solid ' + C.line + ';font-size:11.5px"><span style="color:' + C.ink3 + '">' + l + '</span><span style="font-family:' + C.mono + ';color:' + (c || C.ink) + '">' + v + "</span></div>";
  const feedRow = (f) => { const col = { land: C.good, rej: C.ink3, halt: C.bad, tierC: C.gold, audit: C.route, boot: C.improve }[f.kind] || C.ink3;
    return '<div style="display:flex;gap:8px;padding:4px 0;border-top:1px solid ' + C.line + ';font:10.5px ' + C.mono + '"><span style="color:' + col + ';min-width:34px">' + f.kind + "</span><span style=\"color:" + C.ink2 + '">' + esc(f.text) + "</span></div>"; };
  const auditRows = O.lastAudit ? O.lastAudit.rows.map(r =>
    '<div style="display:flex;gap:7px;padding:3px 0;border-top:1px solid ' + C.line + ';font:10.5px ' + C.mono + '"><span style="color:' + (r.pass ? C.good : C.bad) + '">' + (r.pass ? "PASS" : "FAIL") + '</span><span style="color:' + C.ink2 + ';min-width:26px">' + r.id + '</span><span style="color:' + C.ink3 + '">' + esc(r.name) + "</span></div>").join("") : "";
  O.el.innerHTML =
    '<div style="border:1px solid ' + C.line + ';border-radius:10px;background:' + C.panel + ';padding:12px">' +
    '<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:8px">' +
      btn("cycle", "▶ Run cycle", C.improve, "one governed cycle: harden → search → verify → land") +
      btn("auto", s.auto ? "⏸ Auto" : "▷ Auto", s.auto ? C.gold : C.ink2, "one cycle every ~1.4s") +
      btn("audit", "⚖ Audit", C.route, "independent re-derivation · 14 checks") +
      (s.halted ? btn("resume", "⟲ Resume", C.bad, "human control — clears the breaker") : "") +
      btn("export", "⭳ Export", C.ink2, "download full engine state as JSON") +
      btn("reset", "⌫ Reset", C.ink3, "wipe engine state and reseed the galaxy") +
    "</div>" +
    (s.halted ? '<div style="border:1px solid ' + C.bad + ';color:' + C.bad + ';border-radius:8px;padding:7px 9px;font:11px ' + C.mono + ';margin-bottom:8px">⛔ HALTED — ' + esc(s.haltReason || "") + " · reverted to last sealed generation</div>" : "") +
    '<div style="display:grid;grid-template-columns:1fr 1fr;gap:0 18px">' +
      kv("cycle", s.cycle) + kv("train J", fmt(s.trainJ), C.improve) +
      kv("best J*", fmt(s.bestJ), C.good) + kv("holdout J", fmt(s.holdoutJ)) +
      kv("catch rate", fmt(s.catchRate, 3), C.gold) + kv("false positives", fmt(s.fp, 3)) +
      kv("signatures", s.signatures) + kv("σ", fmt(s.sigma, 3)) +
      kv("landed (total)", s.landedTotal, C.good) + kv("Tier C awaiting human", s.tierCQueued, s.tierCQueued ? C.gold : C.ink3) +
    "</div>" +
    '<div style="margin-top:9px;font:10px ' + C.mono + ';color:' + C.ink3 + '">journal ' + (O.ready ? "hmac-signed · chain-verified each cycle" : "—") + " · state " + (s.persist ? "persisted locally" : "in-memory") + " · Tier C resolves in Approvals with the human key</div>" +
    (O.feed.length ? '<div style="margin-top:8px">' + O.feed.map(feedRow).join("") + "</div>" : "") +
    (auditRows ? '<div style="margin-top:8px"><div style="font:600 10px ' + C.mono + ';color:' + C.ink3 + ';margin-bottom:2px">AUDIT — ' + (O.lastAudit.failures.length ? O.lastAudit.failures.length + " finding(s)" : "all " + O.lastAudit.rows.length + " passed") + "</div>" + auditRows + "</div>" : "") +
    "</div>";
  O.el.querySelectorAll("[data-omrsi]").forEach(b => b.onclick = () => {
    const a = b.getAttribute("data-omrsi");
    if (a === "cycle") runOne(); else if (a === "auto") auto(); else if (a === "audit") audit();
    else if (a === "resume") resume(); else if (a === "export") exportState();
    else if (a === "reset") { if (!hasDoc() || window.confirm("Wipe OM-RSI state and reseed?")) reset(); }
  });
}
function mount(el) {
  if (!el) return;
  if (typeof el === "string" && hasDoc()) el = document.getElementById(el);
  O.el = el; if (!O.ready) init(); render();
}

/* ── expose ──────────────────────────────────────────────────────────────── */
const API = { init, runOne, cycle, auto, resume, reset, status, audit, queue: () => (O.ready ? loadState(O.ctx).tierC : []),
  approveTierC, bridgeTrial, mount, exportState, importState, onUpdate: (cb) => O.listeners.push(cb),
  get ready() { return O.ready; }, get halted() { return O.ready ? !!loadState(O.ctx).halted : false; },
  _engine: { makeContext, runCycle, loadState, Wiki, thetaSpec, runAudit, evaluate }, ROOT };
if (typeof window !== "undefined") {
  window.OMRSI = API;
  if (hasDoc()) {
    const kick = () => setTimeout(() => { try { init(); } catch (e) { console.error("OMRSI init failed", e); } }, 250);
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", kick); else kick();
  }
}
if (typeof globalThis !== "undefined") globalThis.__OMRSI_API = API;
