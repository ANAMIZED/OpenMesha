/* ── om-rsi browser shims ─────────────────────────────────────────────────
   Everything the Node source needs from node:fs / node:path / node:crypto,
   reimplemented for a single-page context: an in-memory virtual filesystem,
   a synchronous pure-JS SHA-256 + HMAC, and keyed identities stored in the
   VFS. No async, no WebCrypto dependency, byte-identical hashing vs Node. */

/* pure-JS SHA-256 (FIPS 180-4), synchronous, utf8 input, hex or bytes out */
const __K = [0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
function __utf8(s){const out=[];for(let i=0;i<s.length;i++){let c=s.charCodeAt(i);
  if(c<0x80)out.push(c);
  else if(c<0x800){out.push(0xc0|c>>6,0x80|c&63);}
  else if(c>=0xd800&&c<0xdc00&&i+1<s.length){const c2=s.charCodeAt(i+1);
    if(c2>=0xdc00&&c2<0xe000){c=0x10000+((c-0xd800)<<10)+(c2-0xdc00);i++;
      out.push(0xf0|c>>18,0x80|c>>12&63,0x80|c>>6&63,0x80|c&63);continue;}
    out.push(0xe0|c>>12,0x80|c>>6&63,0x80|c&63);}
  else out.push(0xe0|c>>12,0x80|c>>6&63,0x80|c&63);}
  return out;}
function __sha256bytes(bytes){
  const l=bytes.length,bl=l*8,msg=bytes.slice();
  msg.push(0x80);while(msg.length%64!==56)msg.push(0);
  const hi=Math.floor(bl/0x100000000);
  msg.push(hi>>>24&255,hi>>>16&255,hi>>>8&255,hi&255,bl>>>24&255,bl>>>16&255,bl>>>8&255,bl&255);
  let h0=0x6a09e667,h1=0xbb67ae85,h2=0x3c6ef372,h3=0xa54ff53a,h4=0x510e527f,h5=0x9b05688c,h6=0x1f83d9ab,h7=0x5be0cd19;
  const w=new Array(64);
  for(let i=0;i<msg.length;i+=64){
    for(let t=0;t<16;t++)w[t]=msg[i+t*4]<<24|msg[i+t*4+1]<<16|msg[i+t*4+2]<<8|msg[i+t*4+3];
    for(let t=16;t<64;t++){const a=w[t-15],b=w[t-2];
      const s0=(a>>>7|a<<25)^(a>>>18|a<<14)^a>>>3, s1=(b>>>17|b<<15)^(b>>>19|b<<13)^b>>>10;
      w[t]=w[t-16]+s0+w[t-7]+s1|0;}
    let a=h0,b=h1,c=h2,d=h3,e=h4,f=h5,g=h6,hh=h7;
    for(let t=0;t<64;t++){
      const S1=(e>>>6|e<<26)^(e>>>11|e<<21)^(e>>>25|e<<7), ch=e&f^~e&g, t1=hh+S1+ch+__K[t]+w[t]|0;
      const S0=(a>>>2|a<<30)^(a>>>13|a<<19)^(a>>>22|a<<10), mj=a&b^a&c^b&c, t2=S0+mj|0;
      hh=g;g=f;f=e;e=d+t1|0;d=c;c=b;b=a;a=t1+t2|0;}
    h0=h0+a|0;h1=h1+b|0;h2=h2+c|0;h3=h3+d|0;h4=h4+e|0;h5=h5+f|0;h6=h6+g|0;h7=h7+hh|0;}
  const out=[];for(const h of [h0,h1,h2,h3,h4,h5,h6,h7])out.push(h>>>24&255,h>>>16&255,h>>>8&255,h&255);
  return out;}
const __hex=(b)=>b.map(x=>("0"+x.toString(16)).slice(-2)).join("");
function __sha256hex(s){return __hex(__sha256bytes(__utf8(String(s))));}
function hmacSha256(key,msg){
  let k=__utf8(String(key));if(k.length>64)k=__sha256bytes(k);while(k.length<64)k.push(0);
  const ip=k.map(x=>x^0x36),op=k.map(x=>x^0x5c);
  return __hex(__sha256bytes(op.concat(__sha256bytes(ip.concat(__utf8(String(msg)))))));}

/* in-memory virtual filesystem — the subset the om-rsi source actually uses */
const __VFS=new Map(); /* path -> {t:"f",data} | {t:"d"} */
function __norm(p){const parts=String(p).replace(/\\/g,"/").split("/").filter(x=>x!==""&&x!==".");
  const out=[];for(const x of parts){if(x==="..")out.pop();else out.push(x);}return "/"+out.join("/");}
function __parents(p){const parts=p.split("/").filter(Boolean);let cur="";
  for(let i=0;i<parts.length-1;i++){cur+="/"+parts[i];if(!__VFS.has(cur))__VFS.set(cur,{t:"d"});}}
const path={
  join(...a){return __norm(a.filter(x=>x!=null&&x!=="").join("/"));},
  basename(p){const n=__norm(p).split("/");return n[n.length-1]||"/";}
};
function __enoent(p,op){const e=new Error((op||"ENOENT")+": no such file or directory, '"+p+"'");e.code="ENOENT";return e;}
const fs={
  existsSync(p){return __VFS.has(__norm(p));},
  mkdirSync(p,o){p=__norm(p);__parents(p+"/x");if(!__VFS.has(p))__VFS.set(p,{t:"d"});},
  readFileSync(p,enc){p=__norm(p);const n=__VFS.get(p);if(!n||n.t!=="f")throw __enoent(p,"open");return n.data;},
  writeFileSync(p,data){p=__norm(p);__parents(p);__VFS.set(p,{t:"f",data:String(data)});},
  appendFileSync(p,data){p=__norm(p);const n=__VFS.get(p);
    if(n&&n.t==="f")n.data+=String(data);else{__parents(p);__VFS.set(p,{t:"f",data:String(data)});}},
  copyFileSync(a,b){fs.writeFileSync(b,fs.readFileSync(a));},
  readdirSync(p){p=__norm(p);if(!__VFS.has(p))throw __enoent(p,"scandir");
    const pre=p==="/"?"/":p+"/";const seen=new Set();
    for(const k of __VFS.keys()){if(k!==p&&k.startsWith(pre)){const rest=k.slice(pre.length).split("/")[0];if(rest)seen.add(rest);}}
    return [...seen].sort();},
  rmSync(p,o){p=__norm(p);const pre=p+"/";
    for(const k of [...__VFS.keys()])if(k===p||k.startsWith(pre))__VFS.delete(k);},
  cpSync(a,b,o){a=__norm(a);b=__norm(b);const n=__VFS.get(a);
    if(!n)throw __enoent(a,"cp");
    if(n.t==="f"){fs.writeFileSync(b,n.data);return;}
    fs.mkdirSync(b);const pre=a+"/";
    for(const [k,v] of [...__VFS.entries()])if(k.startsWith(pre)){const t=b+k.slice(a.length);
      if(v.t==="d")fs.mkdirSync(t);else fs.writeFileSync(t,v.data);}},
};

/* keyed identities: HMAC-SHA256 stand-ins for the ed25519 pair. Same journal
   API (sign / verify / pubPem). In a browser both secrets share the page's
   origin — the SEPARATION of verifier key vs human key is real, the hardware
   trust boundary is not. Stated honestly in the README and the UI. */
function loadOrCreateKeys(dir,name){
  fs.mkdirSync(dir,{recursive:true});
  const f=path.join(dir,name+".secret");
  if(!fs.existsSync(f)){
    let bytes;try{bytes=Array.from((globalThis.crypto||{}).getRandomValues(new Uint8Array(32)));}
    catch{bytes=Array.from({length:32},()=>Math.floor(Math.random()*256));}
    fs.writeFileSync(f,__hex(bytes));
  }
  const secret=()=>fs.readFileSync(f,"utf8");
  return {
    sign:(d)=>hmacSha256(secret(),String(d)),
    verify:(d,sig)=>{try{return hmacSha256(secret(),String(d))===String(sig);}catch{return false;}},
    pubPem:()=>"hmac-id:"+__sha256hex(secret()).slice(0,16),
  };
}
const sha256=(s)=>__sha256hex(s);
