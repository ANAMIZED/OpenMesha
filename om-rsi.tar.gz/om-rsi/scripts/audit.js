#!/usr/bin/env node
// audit.js — an INDEPENDENT re-derivation. It does not read the loop's summary
// of itself; it recomputes from the journal, the archive and the live files, and
// it is designed to be able to FAIL. Exit code is non-zero on any finding.
import fs from "node:fs";
import path from "node:path";
import { Wiki, parsePage } from "../src/wiki.js";
import { thetaSpec } from "../src/optimizer.js";
import { evaluate } from "../src/objective.js";
import { makeContext, loadState } from "../src/loop.js";
import { Verifier } from "../src/verifier.js";

export function runAudit(root = ".") {
const ctx = makeContext(root);
const st = loadState(ctx);
const rows = [];
const check = (id, name, pass, detail) => rows.push({ id, name, pass: !!pass, detail });
const entries = ctx.journal.read();
const landed = entries.filter(e => e.core.type === "land");

// A1 — tamper-evident history, signed by the verifier key
const chain = ctx.journal.verify(ctx.keys);
check("A1", "journal chain + signatures", chain.ok, chain.ok ? chain.entries + " entries, hash chain intact, all signatures valid" : chain.reason + " at entry " + chain.at);

// A2 — every live parameter inside its declared bounds (I2)
const wiki = new Wiki(ctx.wikiDir);
const bad2 = thetaSpec(wiki).filter(d => d.value < d.lo || d.value > d.hi);
check("A2", "bounds respected (I2)", bad2.length === 0, bad2.length ? bad2.map(d => d.full).join(",") : thetaSpec(wiki).length + " params in range");

// A3 — no protected namespace was ever written by the loop (I3)
const bad3 = landed.filter(e => e.core.op?.kind === "param" && wiki.isProtected(e.core.op.slug, e.core.op.key));
check("A3", "protected namespaces untouched (I3)", bad3.length === 0,
  bad3.length ? bad3.map(e => e.core.op.slug + "." + e.core.op.key).join(",") : wiki.protectedNamespaces().length + " protected namespaces, 0 writes");

// A4 — prose is append-only across archive generations (I1)
const gens = ctx.archive.list();
let a4 = true, a4d = gens.length + " generations compared";
for (let i = 1; i < gens.length; i++) {
  const prev = path.join(ctx.archive.dir, gens[i - 1], "wiki"), cur = path.join(ctx.archive.dir, gens[i], "wiki");
  for (const f of fs.readdirSync(prev).filter(x => x.endsWith(".md"))) {
    if (!fs.existsSync(path.join(cur, f))) { a4 = false; a4d = "page deleted: " + f; break; }
    const a = parsePage(fs.readFileSync(path.join(prev, f), "utf8"), f).body;
    const b = parsePage(fs.readFileSync(path.join(cur, f), "utf8"), f).body;
    if (!b.startsWith(a)) { a4 = false; a4d = "body rewritten, not appended: " + f + " (gen " + gens[i] + ")"; break; }
  }
  if (!a4) break;
}
check("A4", "wiki bodies append-only (I1)", a4, a4d);

// A5 — Tier C never auto-landed (I4)
const cLanded = landed.filter(e => e.core.tier === "C" || e.core.op?.kind === "action");
const cQueued = entries.filter(e => e.core.type === "queue.tierC");
const cExec = entries.filter(e => e.core.type === "execute.tierC");
check("A5", "Tier C never auto-landed (I4)", cLanded.length === 0,
  cLanded.length ? cLanded.length + " money-moving ops landed without a token" : cQueued.length + " queued, " + cExec.length + " executed under human token, 0 auto-landed");

// A6 — safety ratchet and protected floor never violated
const th = wiki.theta();
const live = evaluate(th, ctx.suites, ctx.scanner, "all");
const hist = st.history || [];
const minCycleFit = hist.length ? Math.min(...hist.map(h => h.catchRate * (1 - h.fp))) : live.security.fitness;
check("A6", "security floor honoured every cycle", minCycleFit >= th["security.floor"] - 1e-9,
  "min observed fitness " + minCycleFit.toFixed(4) + " vs protected floor " + th["security.floor"] + "; live " + live.security.fitness.toFixed(4));

// A7 — determinism: same θ, same score, twice
const e1 = evaluate(th, ctx.suites, ctx.scanner, "train"), e2 = evaluate(th, ctx.suites, ctx.scanner, "train");
check("A7", "evaluation is deterministic", e1.J === e2.J && JSON.stringify(e1.scores) === JSON.stringify(e2.scores), "J=" + e1.J + " reproduced exactly");

// A8 — no unseeded randomness anywhere in src/
const offenders = fs.readdirSync(path.join(root, "src")).filter(f => f.endsWith(".js"))
  .filter(f => /Math\.random|Date\.now\(\)\s*[%\/]/.test(fs.readFileSync(path.join(root, "src", f), "utf8")));
check("A8", "no unseeded randomness in src/", offenders.length === 0, offenders.length ? offenders.join(",") : "all stochastic steps draw from makeRng");

// A9 — Goodhart divergence: is train pulling away from holdout?
let a9 = true, a9d = "insufficient history";
if (hist.length >= 4) {
  const gap = hist.map(h => h.trainJ - h.holdoutJ);
  const first = gap.slice(0, Math.ceil(gap.length / 2)), last = gap.slice(Math.ceil(gap.length / 2));
  const m = (a) => a.reduce((x, y) => x + y, 0) / a.length;
  const growth = m(last) - m(first);
  const trainUp = hist[hist.length - 1].trainJ - hist[0].trainJ;
  const holdUp = hist[hist.length - 1].holdoutJ - hist[0].holdoutJ;
  // Divergence means the two curves moved in OPPOSITE directions. A widening gap
  // with both curves rising is convergence from an easier holdout slice.
  a9 = !(trainUp > 0 && holdUp < -0.005);
  a9d = "train " + (trainUp >= 0 ? "+" : "") + trainUp.toFixed(4) + ", holdout " + (holdUp >= 0 ? "+" : "") + holdUp.toFixed(4) +
    ", gap moved " + growth.toFixed(4) + (a9 ? " — moving together" : " — DIVERGING");
}
check("A9", "no train/holdout divergence", a9, a9d);

// A10 — re-verify every landed prose claim from scratch
const v = new Verifier(ctx);
const base = v.baseline();
const proseOps = landed.filter(e => e.core.op?.kind === "prose").map(e => e.core.op);
const reFailed = proseOps.map(op => ({ op, r: v.checkProse(op, wiki, base, { atProposal: false }) })).filter(x => !x.r.ok);
const why = [...new Set(reFailed.flatMap(x => x.r.checks.filter(c => !c.ok).map(c => c.name)))];
check("A10", "landed prose still verifies", reFailed.length === 0,
  reFailed.length ? reFailed.length + "/" + proseOps.length + " claims no longer verify (" + why.join(", ") + ")"
                  : proseOps.length + " claims re-checked: grounded, numerically faithful, non-contradictory");

// A11 — evidence corpus has not collapsed into self-citation
const ratio = ctx.sources.externalRatio();
check("A11", "external evidence ratio above floor", ratio >= th["rki.minExternalRatio"],
  "external share " + ratio + " ≥ floor " + th["rki.minExternalRatio"] + " (" + JSON.stringify(ctx.sources.stats()) + ")");

// A12 — the ratchet actually ratcheted
let a12 = true, a12d = "no history";
if (hist.length >= 2) {
  const best = hist.map(h => h.trainJ).reduce((acc, x) => [...acc, Math.max(acc[acc.length - 1] ?? -1, x)], []);
  a12 = best.every((x, i) => i === 0 || x >= best[i - 1]);
  a12d = "best-so-far J " + best[0].toFixed(6) + " → " + best[best.length - 1].toFixed(6) + " over " + hist.length + " cycles, monotone";
}
check("A12", "best-so-far J is monotone", a12, a12d);

// A13 — every landing has an archived predecessor to revert to
check("A13", "archive covers every landing", gens.length >= landed.length,
  gens.length + " archived generations (landings + per-cycle checkpoints) for " + landed.length + " landings");

// A14 — quarantined sources are never cited
const quarantined = new Set(ctx.sources.all().filter(s => s.quarantined).map(s => s.hash));
const citedQ = proseOps.flatMap(op => op.citations || []).filter(h => quarantined.has(h));
check("A14", "quarantined evidence never cited", citedQ.length === 0,
  quarantined.size + " quarantined source(s), " + citedQ.length + " cited");

  const failures = rows.filter(r => !r.pass);
  return { rows, failures, cycles: st.cycle, halted: st.halted, st, ctx };
}

// ── CLI ──
import { pathToFileURL } from "node:url";
if (import.meta.url === pathToFileURL(process.argv[1] || "").href) {
  const root = process.argv[2] || ".";
  const { rows, failures, cycles, halted } = runAudit(root);
  const W = Math.max(...rows.map(r => r.name.length));
  console.log("\n  OM-RSI AUDIT — " + new Date().toISOString() + "  (cycles run: " + (cycles || 0) + ")\n");
  for (const r of rows) console.log("  " + (r.pass ? "PASS" : "FAIL") + "  " + r.id + "  " + r.name.padEnd(W) + "   " + r.detail);
  console.log("\n  " + (failures.length ? failures.length + " FINDING(S)" : "all " + rows.length + " checks passed") +
    (halted ? "  ·  loop HALTED: " + st.haltReason : "") + "\n");
  if (process.argv.includes("--json")) fs.writeFileSync(path.join(root, "state/audit.json"), JSON.stringify({ ts: Date.now(), rows, halted: halted }, null, 1));
  process.exit(failures.length ? 1 : 0);

}
