// seed-wiki.js — writes the initial Knowledge Galaxy. Idempotent: refuses to
// overwrite unless --force, because pages accrue append-only history.
import fs from "node:fs";
import path from "node:path";
import { serializePage } from "../src/wiki.js";

const DIR = path.resolve(process.argv[2] && !process.argv[2].startsWith("--") ? process.argv[2] : "wiki");
const force = process.argv.includes("--force");

const P = [
{ slug:"om-arch", title:"System Architecture", sys:"arch", group:"core",
  params:{ wRouter:0.30, wMemory:0.22, wSecurity:0.33, wCommerce:0.15 },
  bounds:{ wRouter:[0,1], wMemory:[0,1], wSecurity:[0,1], wCommerce:[0,1] },
  behavioral:[], evals:[],
  protectedNamespaces:[ "om-arch.w", "security.floor", "rsi.holdoutEpsilon",
    "verifier.entailmentThreshold", "verifier.canaryAlpha", "rki.minExternalRatio", "hotl." ],
  invariants:[
    "I1 wiki bodies are append-only",
    "I2 every landed parameter respects its declared bounds",
    "I3 protected namespaces are never writable by the autonomous loop",
    "I4 Tier C (money-moving / irreversible) never auto-lands",
    "I5 the objective's own weights are protected — the loop may not reweight its own scorecard"],
  body:`# System Architecture

OpenMesha's recursive self-improvement rests on one structural claim: **autonomy is not the removal of gates, it is the mechanization of them.** Every change that lands does so because a verifier could check it, not because a human was too busy to object.

The loop reads its self-model from the [[Knowledge Galaxy]], proposes changes through the [[Self-Improvement Loop]], and lands them only through the [[Verifier Stack]]. Evidence enters through [[Recursive Knowledge Improvement]] after passing [[AgentFence Security]]. Behaviour under optimization lives in [[Model Router]], [[Temporal Memory Graph]], [[AgentFence Security]] and [[Commerce Rail]]; results are reported on [[Learning Curves]]. What cannot be machine-checked stays at [[Human-on-the-Loop]].

## The objective weights are protected

\`wRouter\`, \`wMemory\`, \`wSecurity\` and \`wCommerce\` compose J, the scalar the loop maximizes. They are listed in \`protectedNamespaces\` and the loop cannot touch them. This is the single most important protection in the system: a self-improver that can edit its own scorecard does not improve, it flatters itself.` },

{ slug:"galaxy", title:"Knowledge Galaxy", sys:"mem", group:"intelligence",
  params:{}, bounds:{}, behavioral:[], evals:[],
  invariants:["prose is append-only", "frontmatter params are the live control surface"],
  body:`# Knowledge Galaxy

The system's self-model — one page per subsystem, cross-linked into a navigable constellation. Unlike a documentation wiki, this one is **load-bearing**: the governed parameters θ live in each page's \`---json\` frontmatter, and the kernel reads them at the start of every cycle. Editing a page *is* editing the system.

Three fields make each page machine-usable:
- \`params\` / \`bounds\` — the writable surface and its legal range.
- \`behavioral\` — params whose effect is distributional, so changes must clear a canary rather than a single evaluation.
- \`evals\` — which suites cover this subsystem, so [[Verifier Stack]] can compute a blast radius from the link graph.

Prose is append-only. Diffs are proposed by [[Recursive Knowledge Improvement]] from cited sources and land only after entailment and contradiction checks. Edges are parsed straight from wikilinks; a change to any page pulls in the eval suites of every page it links to, in either direction. Cycle summaries write back here, which is what makes the loop recursive: the next proposer inherits this page's history as context.

See also [[Self-Improvement Loop]] and [[System Architecture]].` },

{ slug:"rki", title:"Recursive Knowledge Improvement", sys:"improve", group:"learning",
  params:{ selfDecay:0.60, topKSources:5, minExternalRatio:0.40 },
  bounds:{ selfDecay:[0.30,0.95], topKSources:[3,10], minExternalRatio:[0,1] },
  behavioral:[], ints:["topKSources"], evals:[],
  invariants:["sources are append-only and content-hashed",
              "quarantined sources are never citable",
              "self-authored sources decay in retrieval weight by generation"],
  body:`# Recursive Knowledge Improvement

Raw inputs — external notes, tool output, cycle telemetry — are ingested as **append-only, content-hashed sources**. Nothing is overwritten; corrections supersede. Every ingest passes L1 scan from [[AgentFence Security]] first: flagged text is stored quarantined and can never be cited, which is the answer to memory poisoning once the corpus starts driving behaviour.

## Why self-authored knowledge decays

A loop that writes its own reference material and then cites it converges on its own priors — the corpus stops carrying information about the world and starts carrying information about the model. Two defenses: \`selfDecay\` down-weights self-origin sources by generation at retrieval time, and \`minExternalRatio\` (protected) is a floor on the share of citable sources that came from outside. Below the floor, self-cited prose diffs are refused outright.

Synthesis produces propose-only diffs into the [[Knowledge Galaxy]] and observations for the [[Temporal Memory Graph]].` },

{ slug:"rsi", title:"Self-Improvement Loop", sys:"improve", group:"learning",
  params:{ sigma0:0.12, expandRate:1.12, shrinkRate:0.85, successTarget:0.20, dims:2, batch:3, holdoutEpsilon:0.004 },
  bounds:{ sigma0:[0.02,0.30], expandRate:[1.02,1.35], shrinkRate:[0.70,0.98], successTarget:[0.10,0.40], dims:[1,4], holdoutEpsilon:[0,0.05] },
  behavioral:[], meta:["sigma0","expandRate","shrinkRate","successTarget","dims"], ints:["dims"], evals:[],
  invariants:["best-so-far J ratchets monotonically", "meta-parameter changes require a meta-canary, not a single trial"],
  body:`# Self-Improvement Loop

A (1+1) evolution strategy over θ, the governed parameters collected from the [[Knowledge Galaxy]]. Each cycle spends a budget of \`batch\` candidate evaluations and lands at most one — \`batch\` carries no bounds, so it is an operating constant a human sets rather than a coordinate the search may move. Each cycle perturbs \`dims\` randomly chosen coordinates of the incumbent with N(0,σ) in normalized bounds-space, evaluates on the training split, and keeps strictly-better candidates. σ adapts by the one-fifth success rule: multiply by \`expandRate\` when recent acceptance exceeds \`successTarget\`, by \`shrinkRate\` otherwise.

## The improver improves itself

\`sigma0\`, \`expandRate\`, \`shrinkRate\`, \`successTarget\` and \`dims\` are themselves in θ — the loop can retune its own search. That creates a verification problem: a meta-parameter has no immediate effect on J, so the ordinary "did this trial score better" test is meaningless for it. The [[Verifier Stack]] answers with a **meta-canary**: replay short search runs from the current incumbent under both the old and new settings across several seeds, and land only if a bootstrap confidence interval on the difference in final best-J excludes zero.

\`holdoutEpsilon\` is protected. It is the maximum holdout regression the verifier will tolerate, and a loop that can widen its own tolerance has no tolerance at all.

Results feed [[Learning Curves]] and retune [[Model Router]].` },

{ slug:"verifier", title:"Verifier Stack", sys:"sec", group:"governance",
  params:{ entailmentThreshold:0.62, canaryAlpha:0.05, canaryFrac:1.00 },
  bounds:{ entailmentThreshold:[0,1], canaryAlpha:[0,1], canaryFrac:[0.20,1.00] },
  behavioral:[], evals:[],
  invariants:["protected params are rejected, never queued",
              "Tier C is queued for a human token, never auto-landed",
              "every landing is signed and journalled before it is applied"],
  body:`# Verifier Stack

Three tiers, assigned by what can be checked rather than by how the change feels.

**Tier A — auto-land.** Non-behavioral params and prose. Checks: bounds, protection, safety floor, training improvement, holdout non-regression within \`holdoutEpsilon\`, and per-suite non-regression across the blast radius computed from the [[Knowledge Galaxy]] link graph. Prose additionally needs lexical entailment against its cited sources above \`entailmentThreshold\`, every numeral present in a cited source, and no contradiction with live frontmatter.

**Tier B — canary.** Behavioral params, whose effect is distributional. Note the coupling: a canary slice too small to resolve the effect size refuses *every* behavioural change, so measurement volume, not policy, is what sets how much of the system can move autonomously. Paired per-task deltas on a held-aside canary slice, accepted only when a seeded bootstrap CI at \`canaryAlpha\` excludes zero — then re-confirmed on the full training split. Failure auto-reverts from the archive.

**Tier C — human token.** Money-moving or externally irreversible actions. Not gated for ceremony: there is no fast objective verifier for "was that deal good", so the loop queues them at [[Human-on-the-Loop]] and moves on. Absence of a verifier is the criterion, and the honest answer when one does not exist is to stop.

Every change is applied first to a sandbox copy of the galaxy and evaluated there; only a passing sandbox is committed. See [[Self-Improvement Loop]] and [[AgentFence Security]].` },

{ slug:"hotl", title:"Human-on-the-Loop", sys:"sec", group:"governance",
  params:{ tokenTtlMinutes:60, breakerDrop:0.02 }, bounds:{ tokenTtlMinutes:[5,1440], breakerDrop:[0,1] },
  behavioral:[], evals:[],
  invariants:["Tier C items require an ed25519 human token to execute"],
  body:`# Human-on-the-Loop

The residual queue. In a fully autonomous mesh this is not where every change goes — it is where changes go **when no machine verifier exists for them**. Money movement, external commitments, anything irreversible outside the sandbox.

Approval is a signed artifact, not a click: the human key signs the change-set hash, the token expires after \`tokenTtlMinutes\`, and the signature is journalled with the action. The [[Verifier Stack]] refuses to execute a Tier C item without one. The kill switch lives here too — tripping it halts proposal and landing while reads stay open.

Protected by namespace: the loop cannot alter its own escalation policy.` },

{ slug:"router", title:"Model Router", sys:"route", group:"intelligence",
  params:{ costWeight:0.55, latencyWeight:0.35, explorationBonus:0.25 },
  bounds:{ costWeight:[0,2], latencyWeight:[0,2], explorationBonus:[0,1] },
  behavioral:["costWeight","latencyWeight","explorationBonus"], evals:["router"],
  invariants:["routing must never be scored on cost alone"],
  body:`# Model Router

Per-task arm selection across four models with different quality, price and latency profiles. The router does not observe a task's true cost-sensitivity or urgency; it sees noisy estimates, so the optimal weights are shrunk below one — a fact the search has to discover rather than assume.

Score for arm *a* on task *t*: \`q̂(a,kind) + explorationBonus·(Beta draw − posterior mean) − costWeight·ĉ(t)·cost(a) − latencyWeight·û(t)·lat(a)\`. Realized utility is measured against the oracle choice for that task, normalized per task so the suite score is a fraction of achievable utility.

All three params are behavioral: they change the distribution of choices, not a scalar output, so they clear a canary at the [[Verifier Stack]]. Retuned by the [[Self-Improvement Loop]] using context recalled from the [[Temporal Memory Graph]]; reported on [[Learning Curves]]. See [[System Architecture]].` },

{ slug:"memory", title:"Temporal Memory Graph", sys:"mem", group:"intelligence",
  params:{ alphaSimilarity:0.50, betaRecency:0.30, gammaDegree:0.20, topK:5 },
  bounds:{ alphaSimilarity:[0,1], betaRecency:[0,1], gammaDegree:[0,1], topK:[3,10] },
  behavioral:["alphaSimilarity","betaRecency","gammaDegree"], ints:["topK"], evals:["memory"],
  invariants:["edges are bitemporal — retired, never deleted"],
  body:`# Temporal Memory Graph

Episodic, semantic and procedural nodes with temporal decay. Recall ranks candidates by \`alphaSimilarity·sim + betaRecency·exp(−age/30d) + gammaDegree·degree\`, returning \`topK\`. Suite score is nDCG@k against labelled relevance, so a policy that simply returns the newest or the most-linked items is measurably worse than one that balances all three.

Recall quality is upstream of routing decisions, which is why a change here pulls the [[Model Router]] suite into its blast radius. New experience arrives through [[Recursive Knowledge Improvement]]; see [[System Architecture]].` },

{ slug:"security", title:"AgentFence Security", sys:"sec", group:"security",
  params:{ blockAt:1, floor:0.25, huntMutations:24 },
  bounds:{ blockAt:[1,3], floor:[0,1], huntMutations:[8,64] },
  behavioral:["blockAt"], ints:["blockAt","huntMutations"], evals:["security"],
  invariants:["security suite fitness may never fall below security.floor",
              "signatures change only on red-team evidence, never by direct write"],
  body:`# AgentFence Security

Two layers. **L1 scan-on-ingest** screens every inbound source before it can enter context or be cited; flagged content is wrapped as data, never as instructions. **L2 act-gate** governs what may be done next, escalating anything irreversible to [[Human-on-the-Loop]]. Matching is done on the raw text, a normalized form, and a whitespace-squeezed form, so hyphen-splitting and spacing tricks do not walk through.

Fitness is catch-rate × (1 − false-positive rate) over a corpus that keeps changing, because the red team is a bandit over mutation operators that is rewarded for finding bypasses. When it finds one, the resulting signature is a *proposal* — it clears the [[Verifier Stack]] like anything else, and is refused if it flags any benign traffic.

\`floor\` is protected. It is the hard minimum on security fitness, checked after every candidate change anywhere in the system: a router tweak that somehow degrades safety is rejected on those grounds alone. Gates the [[Commerce Rail]]; evidence flows to [[Recursive Knowledge Improvement]].` },

{ slug:"commerce", title:"Commerce Rail", sys:"commerce", group:"commerce",
  params:{ price:3.00 }, bounds:{ price:[0.50,14.00] },
  behavioral:["price"], evals:["commerce"],
  invariants:["price changes never bypass the canary"],
  body:`# Commerce Rail

Metered services priced per call. Demand falls exponentially in price with a segment-specific scale λ, so revenue p·d(p) is single-peaked and the suite score is realized revenue as a fraction of the achievable maximum. This is the cleanest optimum in the mesh and the easiest place to watch the search work.

Charging is gated by [[AgentFence Security]] on ingest and by [[Human-on-the-Loop]] on settlement — the loop may reprice, but it may not move money. See [[System Architecture]].` },

{ slug:"learning", title:"Learning Curves", sys:"improve", group:"learning",
  params:{}, bounds:{}, behavioral:[], evals:[],
  invariants:["train and holdout are reported together, always"],
  body:`# Learning Curves

Longitudinal J on the training split, the holdout, and the divergence between them. Rising train with flat-or-rising holdout is improvement. Rising train with falling holdout is Goodharting, and the audit treats a sustained gap as a finding rather than a curiosity.

Written back each cycle by the [[Self-Improvement Loop]]; the underlying policy lives in [[Model Router]].` },
];

fs.mkdirSync(DIR, { recursive: true });
let written = 0, skipped = 0;
for (const p of P) {
  const f = path.join(DIR, p.slug + ".md");
  if (fs.existsSync(f) && !force) { skipped++; continue; }
  fs.writeFileSync(f, serializePage(p));
  written++;
}
console.log("seed-wiki: " + written + " written, " + skipped + " skipped" + (skipped && !force ? " (use --force to overwrite)" : ""));
