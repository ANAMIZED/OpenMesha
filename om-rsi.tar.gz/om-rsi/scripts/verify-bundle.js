// verify-bundle.js — the bundle must BE the system: run it in Node with window
// stubbed, drive 30 cycles, and demand an exactly identical J trajectory to a
// fresh native run. Then the bundled audit must pass all checks in the VFS.
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { execFileSync } from "node:child_process";
import { makeContext, runCycles } from "../src/loop.js";

const R = path.resolve(import.meta.dirname, "..");
const N = parseInt(process.argv[2] || "30", 10);

// native fresh run
const root = fs.mkdtempSync(path.join(os.tmpdir(), "om-native-"));
fs.mkdirSync(path.join(root, "wiki"), { recursive: true });
execFileSync("node", [path.join(R, "scripts/seed-wiki.js"), path.join(root, "wiki"), "--force"], { cwd: R });
fs.cpSync(path.join(R, "seed_notes"), path.join(root, "seed_notes"), { recursive: true });
const nat = runCycles(makeContext(root), N).map(r => ({ c: r.cycle, t: +r.rec.trainJ.toFixed(6), h: +r.rec.holdoutJ.toFixed(6), s: r.rec.signatures, cr: +r.rec.catchRate.toFixed(4) }));
fs.rmSync(root, { recursive: true, force: true });

// bundled run (same process, window stubbed, no document)
globalThis.window = {};
(0, eval)(fs.readFileSync(path.join(R, "dist/om-rsi.browser.js"), "utf8"));
const API = globalThis.__OMRSI_API;
API.init();
const bun = [];
for (let i = 0; i < N; i++) { const r = API.runOne(); if (!r.rec) break;
  bun.push({ c: r.cycle, t: +r.rec.trainJ.toFixed(6), h: +r.rec.holdoutJ.toFixed(6), s: r.rec.signatures, cr: +r.rec.catchRate.toFixed(4) }); }

let same = nat.length === bun.length;
for (let i = 0; i < Math.min(nat.length, bun.length); i++)
  if (JSON.stringify(nat[i]) !== JSON.stringify(bun[i])) { same = false;
    console.error("DIVERGENCE at cycle", i + 1, "\n native", nat[i], "\n bundle", bun[i]); break; }
console.log("parity:", same ? "EXACT over " + N + " cycles" : "FAILED");
console.log(" native  c1", JSON.stringify(nat[0]), "→ c" + N, JSON.stringify(nat[N - 1]));
console.log(" bundle  c1", JSON.stringify(bun[0]), "→ c" + N, JSON.stringify(bun[N - 1]));

const audit = API.audit();
const fails = audit.failures || [];
console.log("bundled audit:", fails.length === 0 ? "all " + audit.rows.length + " checks passed in the VFS" : fails.map(f => f.id + " " + f.name + " · " + f.detail).join("; "));

const st = API.status();
console.log("status:", JSON.stringify({ cycle: st.cycle, bestJ: +(+st.bestJ).toFixed(6), signatures: st.signatures, tierC: st.tierCQueued, halted: st.halted }));
if (!same || fails.length) process.exit(1);

// Tier C human-token path through the bundle
const q = API.queue();
if (q.length) {
  const bad = API.approveTierC("nonexistent");
  const good = API.approveTierC(q[0].id);
  console.log("tierC:", bad.error ? "unknown id refused ✓" : "GUARD FAILED", "·", good.ok ? "executed under human token ✓" : "EXEC FAILED " + JSON.stringify(good));
  if (!bad.error || !good.ok) process.exit(1);
}
console.log("bundle verified: it IS the system.");
