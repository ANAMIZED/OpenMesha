// verify-shims.js — fuzz the pure-JS crypto against node:crypto and smoke the VFS.
import crypto from "node:crypto";
import fs from "node:fs";
import vm from "node:vm";
const src = fs.readFileSync("browser/shims.js", "utf8");
const sandbox = { globalThis: {}, console };
sandbox.globalThis.crypto = crypto.webcrypto;
vm.createContext(sandbox);
vm.runInContext(src + "\n;__EXPORT={__sha256hex,hmacSha256,fs,path,loadOrCreateKeys,sha256};", sandbox);
const S = sandbox.__EXPORT;

const rnd = (n) => { let s = ""; for (let i = 0; i < n; i++) {
  const r = Math.random(); s += r < 0.6 ? String.fromCharCode(32 + Math.floor(Math.random() * 95))
    : r < 0.8 ? String.fromCharCode(0x80 + Math.floor(Math.random() * 0x1000))
    : String.fromCodePoint(0x10000 + Math.floor(Math.random() * 0x1000)); } return s; };
let n = 0;
for (let i = 0; i < 600; i++) {
  const m = i < 4 ? ["", "a", "abc", "The quick brown fox jumps over the lazy dog"][i] : rnd(Math.floor(Math.random() * 300));
  const want = crypto.createHash("sha256").update(String(m)).digest("hex");
  if (S.__sha256hex(m) !== want) { console.error("SHA MISMATCH", JSON.stringify(m)); process.exit(1); } n++;
}
for (let i = 0; i < 300; i++) {
  const k = rnd(1 + Math.floor(Math.random() * 120)), m = rnd(Math.floor(Math.random() * 200));
  const want = crypto.createHmac("sha256", k).update(String(m)).digest("hex");
  if (S.hmacSha256(k, m) !== want) { console.error("HMAC MISMATCH", JSON.stringify(k)); process.exit(1); } n++;
}
console.log("crypto fuzz:", n, "vectors match node:crypto exactly");

const { fs: V, path: P } = S;
V.mkdirSync("/a/b/c", { recursive: true });
V.writeFileSync("/a/b/c/x.txt", "one");
V.appendFileSync("/a/b/c/x.txt", "+two");
V.writeFileSync("/a/b/y.md", "hello");
if (V.readFileSync("/a/b/c/x.txt", "utf8") !== "one+two") throw new Error("rw");
if (JSON.stringify(V.readdirSync("/a/b")) !== JSON.stringify(["c", "y.md"])) throw new Error("readdir " + V.readdirSync("/a/b"));
V.cpSync("/a/b", "/copy", { recursive: true });
if (V.readFileSync("/copy/c/x.txt") !== "one+two") throw new Error("cp -r");
V.rmSync("/a", { recursive: true, force: true });
if (V.existsSync("/a/b/y.md") || !V.existsSync("/copy/y.md")) throw new Error("rm -r");
V.copyFileSync("/copy/y.md", "/y2.md");
if (V.readFileSync("/y2.md") !== "hello") throw new Error("copyFile");
if (P.join("/root", "state", "j.jsonl") !== "/root/state/j.jsonl" || P.basename("/x/y/z.md") !== "z.md") throw new Error("path");
let threw = false; try { V.readFileSync("/nope"); } catch (e) { threw = /ENOENT|no such/.test(e.message); }
if (!threw) throw new Error("missing-file must throw");
const k1 = S.loadOrCreateKeys("/keys", "verifier"), k2 = S.loadOrCreateKeys("/keys", "human");
const sig = k1.sign("hello");
if (!k1.verify("hello", sig) || k1.verify("hellx", sig) || k2.verify("hello", sig)) throw new Error("keys");
const k1b = S.loadOrCreateKeys("/keys", "verifier");
if (k1b.sign("hello") !== sig) throw new Error("key persistence");
console.log("VFS + path + keys: all shim behaviours verified");
