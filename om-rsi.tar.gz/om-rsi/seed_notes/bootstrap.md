# Bootstrap confidence intervals for paired differences
The percentile bootstrap estimates the sampling distribution of a statistic by resampling the observed data with replacement many times and reading percentiles off the resulting distribution. For paired measurements the differences are resampled directly, which controls for per-item variation and gives a confidence interval on the mean difference.
A change is accepted as an improvement only when the lower bound of the interval excludes zero at the chosen alpha level. Seeding the resampler makes the test deterministic, so a verifier and an auditor examining the same data reach the same verdict.
Paired testing on a slice reserved for that purpose avoids spending the holdout on repeated significance tests.
