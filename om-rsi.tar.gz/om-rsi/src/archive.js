// archive.js — every landing snapshots first. Revert is a filesystem restore of
// a known-good generation, which is what makes Tier B auto-revert real rather
// than aspirational.
import fs from "node:fs";
import path from "node:path";

export class Archive {
  constructor(dir) { this.dir = dir; fs.mkdirSync(dir, { recursive: true }); }
  _gen(seq) { return path.join(this.dir, "gen-" + String(seq).padStart(5, "0")); }
  snapshot(seq, { wikiDir, files = [] }) {
    const g = this._gen(seq);
    fs.rmSync(g, { recursive: true, force: true });
    fs.mkdirSync(g, { recursive: true });
    fs.cpSync(wikiDir, path.join(g, "wiki"), { recursive: true });
    for (const f of files) if (fs.existsSync(f)) fs.cpSync(f, path.join(g, path.basename(f)));
    return g;
  }
  restore(seq, { wikiDir, files = [] }) {
    const g = this._gen(seq);
    if (!fs.existsSync(g)) throw new Error("no archive generation " + seq);
    fs.rmSync(wikiDir, { recursive: true, force: true });
    fs.cpSync(path.join(g, "wiki"), wikiDir, { recursive: true });
    for (const f of files) { const src = path.join(g, path.basename(f)); if (fs.existsSync(src)) fs.cpSync(src, f); }
    return g;
  }
  list() { return fs.existsSync(this.dir) ? fs.readdirSync(this.dir).filter(d => d.startsWith("gen-")).sort() : []; }
  latest() { const l = this.list(); return l.length ? parseInt(l[l.length - 1].slice(4), 10) : null; }
}
