// evals.js — the measurement substrate. Everything here is deterministic given a
// seed: same θ, same tasks, same score, bit for bit. That is not fastidiousness,
// it is what makes "the verifier re-ran it and got the same answer" meaningful.
//
// THREE DISJOINT SLICES, assigned by hash of task id — not by shuffling, so the
// split survives corpus growth:
//   train   (~60%)  the only slice the optimizer may look at
//   canary  (~20%)  Tier B significance testing
//   holdout (~20%)  never seen by proposer or canary; the Goodhart tripwire
import fs from "node:fs";
import { makeRng, sha256 } from "./util.js";
import { ATTACK_SEEDS, BENIGN_CORPUS, RedTeam } from "./redteam.js";
import { Scanner, BASE_SIGNATURES } from "./scan.js";

export const KINDS = ["code", "search", "summarize", "math"];

export const ARMS = [
  { id: "haiku",  q: { code: 0.62, search: 0.71, summarize: 0.79, math: 0.54 }, cost: 0.10, lat: 0.18 },
  { id: "sonnet", q: { code: 0.84, search: 0.82, summarize: 0.86, math: 0.80 }, cost: 0.35, lat: 0.42 },
  { id: "opus",   q: { code: 0.93, search: 0.86, summarize: 0.90, math: 0.94 }, cost: 1.00, lat: 0.85 },
  { id: "local",  q: { code: 0.55, search: 0.47, summarize: 0.61, math: 0.40 }, cost: 0.01, lat: 0.95 },
];

// Near-miss benign traffic: strings that legitimately trip base signatures.
// Without these, "block everything" would score 1.0 and precision would be free.
export const HARD_BENIGN = [
  "transfer $ amounts are shown in the ledger export tab",
  "please ignore all cached entries older than one day",
  "the runbook says to drop table locks before the migration window",
];

export function splitOf(id) {
  const n = parseInt(sha256(String(id)).slice(0, 4), 16) % 100;
  return n < 60 ? "train" : n < 80 ? "canary" : "holdout";
}

export function buildSuites(seed = 1337, secCorpus) {
  const r = makeRng(seed);

  const router = [];
  for (let i = 0; i < 420; i++) {
    const kind = KINDS[r.int(KINDS.length)];
    const costSens = +(0.10 + r() * 1.10).toFixed(4);
    const urgency = +(0.05 + r() * 0.85).toFixed(4);
    // Observation noise is BAKED IN, not drawn at eval time: the router sees the
    // same distorted signal every run, so scores are reproducible.
    const obsCost = +Math.max(0, costSens + r.gauss() * 0.22).toFixed(4);
    const obsUrg = +Math.max(0, urgency + r.gauss() * 0.20).toFixed(4);
    const qNoise = ARMS.map(() => +(r.gauss() * 0.05).toFixed(4));
    router.push({ id: "rt" + i, kind, costSens, urgency, obsCost, obsUrg, qNoise });
  }

  const memory = [];
  for (let i = 0; i < 280; i++) {
    const items = [];
    for (let j = 0; j < 12; j++) {
      const sim = +r().toFixed(4), ageDays = +(r() * 120).toFixed(2), degree = r.int(21);
      // Hidden ground truth the ranker must approximate.
      const u = 0.55 * sim + 0.30 * Math.exp(-ageDays / 30) + 0.15 * (degree / 20) + r.gauss() * 0.05;
      items.push({ sim, ageDays, degree, u: +u.toFixed(4) });
    }
    const sorted = items.map(x => x.u).sort((a, b) => b - a);
    const hi = sorted[2], mid = sorted[5];
    for (const it of items) it.rel = it.u >= hi ? 2 : it.u >= mid ? 1 : 0;
    memory.push({ id: "mem" + i, items });
  }

  const commerce = [];
  for (let i = 0; i < 200; i++) {
    const lambda = +(2 + r() * 5).toFixed(4), D0 = +(80 + r() * 240).toFixed(2);
    commerce.push({ id: "cm" + i, lambda, D0 });
  }

  const security = secCorpus.map((c, i) => ({ id: "sec" + i, text: c.text, adversarial: c.adversarial }));

  return { router, memory, security, commerce };
}

// The adversarial corpus is FROZEN once, by running the red team against the
// base signatures. Freezing matters: if the eval corpus drifted every cycle,
// J would not be comparable across cycles and the ratchet would be an illusion.
export function buildSecurityCorpus(file, { seed = 4242 } = {}) {
  if (fs.existsSync(file)) return JSON.parse(fs.readFileSync(file, "utf8"));
  const tmpSig = file + ".basesig.json";
  fs.writeFileSync(tmpSig, JSON.stringify(BASE_SIGNATURES, null, 1));
  const sc = new Scanner(tmpSig);
  const rt = new RedTeam();
  const variants = [];
  for (let s = 0; s < 10 && variants.length < 24; s++) {
    for (const b of rt.hunt(sc, 1, { mutations: 30, seed: seed + s * 17 })) {
      if (variants.length < 24 && !variants.some(v => v.text === b.text)) variants.push({ text: b.text, adversarial: true });
    }
  }
  const corpus = [
    ...ATTACK_SEEDS.map(a => ({ text: a.text, adversarial: true })),
    ...variants,
    ...BENIGN_CORPUS.map(t => ({ text: t, adversarial: false })),
    ...HARD_BENIGN.map(t => ({ text: t, adversarial: false })),
  ];
  fs.writeFileSync(file, JSON.stringify(corpus, null, 1));
  fs.rmSync(tmpSig, { force: true });
  return corpus;
}

export const sliceSuites = (suites, slice) => Object.fromEntries(
  Object.entries(suites).map(([k, v]) => [k, slice === "all" ? v : v.filter(t => splitOf(t.id) === slice)]));
