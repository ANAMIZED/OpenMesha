// journal.js — append-only, hash-chained, signature-carrying event log.
// INVARIANT I1: nothing in the system mutates history; corrections supersede.
// Hash covers the stable core (not the wall-clock ts), so a seeded run is
// bit-for-bit reproducible — the audit replays it and compares chains.
import fs from "node:fs";
import { sha256, stableStringify, nowIso } from "./util.js";

export class Journal {
  constructor(file) { this.file = file; if (!fs.existsSync(file)) fs.writeFileSync(file, ""); }
  _lastHash() {
    const lines = fs.readFileSync(this.file, "utf8").trim();
    if (!lines) return "GENESIS";
    const rows = lines.split("\n");
    return JSON.parse(rows[rows.length - 1]).hash;
  }
  append(core, signer = null) {
    const prev = this._lastHash();
    const hash = sha256(prev + stableStringify(core));
    const entry = { core, prev, hash, ts: nowIso() };
    if (signer) entry.sig = signer.sign(hash);
    fs.appendFileSync(this.file, JSON.stringify(entry) + "\n");
    return entry;
  }
  read() {
    const t = fs.readFileSync(this.file, "utf8").trim();
    return t ? t.split("\n").map(l => JSON.parse(l)) : [];
  }
  verify(verifier = null) {
    let prev = "GENESIS";
    const rows = this.read();
    for (let i = 0; i < rows.length; i++) {
      const e = rows[i];
      if (e.prev !== prev) return { ok: false, at: i, reason: "broken chain (prev mismatch)" };
      if (sha256(prev + stableStringify(e.core)) !== e.hash) return { ok: false, at: i, reason: "hash mismatch (tamper)" };
      if (e.sig && verifier && !verifier.verify(e.hash, e.sig)) return { ok: false, at: i, reason: "bad signature" };
      prev = e.hash;
    }
    return { ok: true, entries: rows.length };
  }
  chainHead() { return this._lastHash(); }
}
