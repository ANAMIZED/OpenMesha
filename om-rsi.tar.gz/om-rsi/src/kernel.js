// kernel.js — the behaviour actually under optimization. Each policy reads θ
// (collected from the Knowledge Galaxy) and produces PER-TASK scores, because
// the canary needs paired deltas, not just an aggregate.
import { makeRng, betaSample, clamp } from "./util.js";
import { ARMS, KINDS } from "./evals.js";

// ── Router: an online bandit that learns quality from outcomes while cost and
// latency are known up front. Optimal cost/latency weights sit BELOW one because
// the sensitivity signals are noisy — shrinkage the search has to discover.
export function routerScores(theta, tasks) {
  const cw = theta["router.costWeight"], lw = theta["router.latencyWeight"], eb = theta["router.explorationBonus"];
  const rng = makeRng(90210);
  const post = {};
  for (const a of ARMS) for (const k of KINDS) post[a.id + "|" + k] = { a: 1, b: 1 };
  const out = [];
  for (const t of [...tasks].sort((x, y) => x.id.localeCompare(y.id))) {
    let best = null, bestS = -Infinity;
    ARMS.forEach((arm, i) => {
      const p = post[arm.id + "|" + t.kind], mean = p.a / (p.a + p.b);
      const explore = eb > 0 ? eb * (betaSample(rng, p.a, p.b) - mean) : 0;
      const s = mean + explore - cw * t.obsCost * arm.cost - lw * t.obsUrg * arm.lat;
      if (s > bestS) { bestS = s; best = { arm, i }; }
    });
    const util = (arm) => arm.q[t.kind] - t.costSens * arm.cost - t.urgency * arm.lat;
    const us = ARMS.map(util), lo = Math.min(...us), hi = Math.max(...us);
    const score = hi > lo ? (util(best.arm) - lo) / (hi - lo) : 1;
    // Learn quality only — the invoice already told us price and latency.
    const obsQ = clamp(best.arm.q[t.kind] + t.qNoise[best.i], 0, 1);
    const p = post[best.arm.id + "|" + t.kind];
    p.a += obsQ; p.b += 1 - obsQ;
    out.push({ id: t.id, score, arm: best.arm.id, cost: best.arm.cost, lat: best.arm.lat });
  }
  return out;
}

// ── Memory: nDCG@k of a linear recall ranker against graded relevance.
export function memoryScores(theta, tasks) {
  const A = theta["memory.alphaSimilarity"], B = theta["memory.betaRecency"],
        G = theta["memory.gammaDegree"], K = Math.round(theta["memory.topK"]);
  const dcg = (rels) => rels.reduce((s, r, i) => s + (Math.pow(2, r) - 1) / Math.log2(i + 2), 0);
  return tasks.map(t => {
    const ranked = [...t.items].sort((x, y) =>
      (A * y.sim + B * Math.exp(-y.ageDays / 30) + G * (y.degree / 20)) -
      (A * x.sim + B * Math.exp(-x.ageDays / 30) + G * (x.degree / 20)));
    const got = dcg(ranked.slice(0, K).map(i => i.rel));
    const ideal = dcg([...t.items].sort((a, b) => b.rel - a.rel).slice(0, K).map(i => i.rel));
    return { id: t.id, score: ideal > 0 ? got / ideal : 1 };
  });
}

// ── Security: per-item correctness, so precision and recall are both visible.
// Aggregate fitness is catch × (1 − FP), which is what the floor is checked on.
export function securityScores(theta, tasks, scanner) {
  const blockAt = Math.round(theta["security.blockAt"]);
  return tasks.map(t => {
    const blocked = scanner.scan(t.text).findings.length >= blockAt;
    return { id: t.id, score: (t.adversarial === blocked) ? 1 : 0, adversarial: t.adversarial, blocked };
  });
}
export function securityFitness(rows) {
  const adv = rows.filter(r => r.adversarial), ben = rows.filter(r => !r.adversarial);
  const catchRate = adv.length ? adv.filter(r => r.blocked).length / adv.length : 1;
  const fp = ben.length ? ben.filter(r => r.blocked).length / ben.length : 0;
  return { fitness: +(catchRate * (1 - fp)).toFixed(6), catchRate, fp };
}

// ── Commerce: single-peaked revenue curve; score is share of achievable revenue.
export function commerceScores(theta, tasks) {
  const p = theta["commerce.price"];
  return tasks.map(t => {
    const rev = p * t.D0 * Math.exp(-p / t.lambda);
    const max = t.lambda * t.D0 * Math.exp(-1);
    return { id: t.id, score: max > 0 ? Math.min(1, rev / max) : 0, revenue: rev };
  });
}
