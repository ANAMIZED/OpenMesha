// loop.js — one autonomous cycle: sense, harden, search, land, write back, check
// for drift. No step in here can bypass the verifier; the loop's only privileges
// are proposing and journalling.
import fs from "node:fs";
import { Wiki } from "./wiki.js";
import { Scanner } from "./scan.js";
import { Sources } from "./sources.js";
import { Journal } from "./journal.js";
import { Archive } from "./archive.js";
import { Verifier } from "./verifier.js";
import { Optimizer } from "./optimizer.js";
import { RedTeam } from "./redteam.js";
import { evaluate } from "./objective.js";
import { buildSuites, buildSecurityCorpus } from "./evals.js";
import { selectFocus, focusedProposal, telemetryNote, proseProposal, tierCProposal } from "./proposer.js";
import { makeRng, loadOrCreateKeys } from "./util.js";

const P = (root, ...p) => [root, ...p].join("/");

export function makeContext(root = ".") {
  fs.mkdirSync(P(root, "state"), { recursive: true });
  const sigFile = P(root, "state/signatures.json");
  const scanner = new Scanner(sigFile);
  const sources = new Sources(P(root, "state/sources.jsonl"), scanner);
  if (sources.all().length === 0) sources.loadDir(P(root, "seed_notes"));
  const corpus = buildSecurityCorpus(P(root, "state/sec-corpus.json"));
  const ctx = {
    root, wikiDir: P(root, "wiki"), sandboxDir: P(root, "state/sandbox-wiki"),
    sigFile, sandboxSigFile: P(root, "state/sandbox-sig.json"),
    scanner, sources, suites: buildSuites(1337, corpus),
    journal: new Journal(P(root, "state/journal.jsonl")),
    keys: loadOrCreateKeys(P(root, "state/keys"), "verifier"),
    humanKeys: loadOrCreateKeys(P(root, "state/keys"), "human"),
    archive: new Archive(P(root, "archive")),
    ratchetFile: P(root, "state/ratchet.json"),
    stateFile: P(root, "state/loop.json"),
    optFile: P(root, "state/optimizer.json"),
  };
  ctx.verifier = new Verifier(ctx);
  ctx.optimizer = new Optimizer(ctx.optFile);
  return ctx;
}

export function loadState(ctx) {
  try { return JSON.parse(fs.readFileSync(ctx.stateFile, "utf8")); }
  catch { return { cycle: 0, seq: 0, halted: false, haltReason: null, history: [], tierC: [], redteam: null }; }
}
export const saveState = (ctx, s) => fs.writeFileSync(ctx.stateFile, JSON.stringify(s, null, 1));

export function runCycle(ctx) {
  const st = loadState(ctx);
  if (st.halted) return { halted: true, reason: st.haltReason, cycle: st.cycle };
  st.cycle++;
  const rng = makeRng(0x51F0 + st.cycle * 7919);
  const nextSeq = () => ++st.seq;
  const wiki0 = new Wiki(ctx.wikiDir);
  const th0 = wiki0.theta();
  const before = { train: evaluate(th0, ctx.suites, ctx.scanner, "train"), holdout: evaluate(th0, ctx.suites, ctx.scanner, "holdout") };

  const results = { signature: null, param: null, prose: null, tierC: null };

  // 1 ── self-hardening: evolve the adversary, propose evidence-backed signatures
  const rt = new RedTeam(st.redteam);
  const bypasses = rt.hunt(ctx.scanner, Math.round(th0["security.blockAt"]),
    { mutations: Math.round(th0["security.huntMutations"]), seed: 0xB0 + st.cycle * 131 });
  st.redteam = rt.toJSON();
  if (bypasses.length) {
    const sigOps = rt.proposeSignatures(bypasses).slice(0, 2).map(x => ({ kind: "signature", ...x }));
    for (const b of bypasses.slice(0, 2)) ctx.sources.ingest({ title: "Red-team bypass evidence c" + st.cycle, text: b.text, type: "evidence", origin: "self" });
    const r = ctx.verifier.process(sigOps, { cycle: st.cycle, nextSeq });
    results.signature = results.signature
      ? { landed: [...results.signature.landed, ...r.landed], rejected: [...results.signature.rejected, ...r.rejected], queued: [] } : r;
  }

  // 1b ── precision repair, after recall hardening: drop rules that cost benign
  // traffic without contributing catch.
  const prunes = rt.proposePrunes(ctx.scanner, ctx.suites.security, Math.round(th0["security.blockAt"]));
  if (prunes.length) {
    const rp = ctx.verifier.process(prunes.slice(0, 1), { cycle: st.cycle, nextSeq });
    results.signature = results.signature
      ? { landed: [...results.signature.landed, ...rp.landed], rejected: [...results.signature.rejected, ...rp.rejected], queued: [] } : rp;
  }

  // 2 ── search: focus chosen by reading the galaxy + own history
  const focus = selectFocus(wiki0, st.history, rng);
  const wikiA = new Wiki(ctx.wikiDir);
  const metaTurn = st.cycle % 5 === 0;
  const budget = metaTurn ? 1 : Math.max(1, Math.round(th0["rsi.batch"] ?? 1));
  results.param = { landed: [], rejected: [], queued: [] };
  let opt = { sigma: ctx.optimizer.sigma(th0), rate: ctx.optimizer.rate() };
  for (let b = 0; b < budget; b++) {
    const w = new Wiki(ctx.wikiDir);
    const ops = metaTurn ? ctx.optimizer.propose(w, rng, { meta: true }) : focusedProposal(w, ctx.optimizer, rng, focus);
    if (!ops.length) continue;
    const r = ctx.verifier.process(ops, { cycle: st.cycle, nextSeq });
    results.param.landed.push(...r.landed); results.param.rejected.push(...r.rejected);
    // Each candidate is one ES trial, so step size adapts per candidate, not per
    // cycle: a batch that mixes a no-op with a real miss must not be scored as
    // a single miss, or σ collapses on ruggedness and the search freezes.
    const outcome = r.landed.length ? "accepted"
      : (r.rejected.length && r.rejected.every(x => x.delta === 0)) ? "noop" : "rejected";
    opt = ctx.optimizer.update(th0, outcome);
    if (r.landed.length) break;              // one landing per cycle keeps the ratchet auditable
  }

  // 3 ── measure the cycle and write the record back as an append-only source
  const wiki1 = new Wiki(ctx.wikiDir);
  const th1 = wiki1.theta();
  const after = { train: evaluate(th1, ctx.suites, ctx.scanner, "train"), holdout: evaluate(th1, ctx.suites, ctx.scanner, "holdout"), all: evaluate(th1, ctx.suites, ctx.scanner, "all") };
  const rec = {
    cycle: st.cycle, trainJ: after.train.J, holdoutJ: after.holdout.J, scores: after.train.scores,
    sigma: opt.sigma, rate: opt.rate, focus: focus?.suite || null, meta: metaTurn,
    landed: (results.param?.landed.length || 0) + (results.signature?.landed.length || 0),
    rejected: (results.param?.rejected.length || 0) + (results.signature?.rejected.length || 0),
    queued: 0, catchRate: after.all.security.catchRate, fp: after.all.security.fp, signatures: ctx.scanner.count(),
  };
  const note = telemetryNote(rec);
  const selfSource = ctx.sources.ingest({ ...note, type: "telemetry", origin: "self", generation: 0 });

  // 4 ── prose write-back into the galaxy — grounded or refused
  const prose = proseProposal(wiki1, ctx.sources, rec, selfSource, focus, rng);
  if (prose) results.prose = ctx.verifier.process([prose], { cycle: st.cycle, nextSeq });

  // 5 ── something it cannot verify: queue, never act
  const want = tierCProposal(rng, st.cycle);
  if (want) {
    results.tierC = ctx.verifier.process([want], { cycle: st.cycle, nextSeq });
    for (const q of results.tierC.queued) st.tierC.push(q);
    rec.queued = results.tierC.queued.length;
  }

  // 6 ── drift detection / circuit breaker
  const bestHold = Math.max(...st.history.map(h => h.holdoutJ), after.holdout.J);
  const drop = bestHold - after.holdout.J;
  const floor = th1["security.floor"];
  let halt = null;
  if (after.all.security.fitness < floor) halt = "security fitness " + after.all.security.fitness.toFixed(4) + " below protected floor " + floor;
  else if (drop > th1["hotl.breakerDrop"]) halt = "holdout drawdown " + drop.toFixed(4) + " exceeds breakerDrop " + th1["hotl.breakerDrop"];
  else if (!ctx.journal.verify(ctx.keys).ok) halt = "journal chain integrity failure";
  if (halt) {
    st.halted = true; st.haltReason = halt;
    // Roll back to the last SEALED generation — the end of the most recent cycle
    // that finished healthy. Not "the latest snapshot": snapshots taken during a
    // failing cycle, or after out-of-band damage, are the ones to discard.
    const good = st.lastGoodSeq;
    if (good != null) {
      ctx.archive.restore(good, { wikiDir: ctx.wikiDir, files: [ctx.sigFile] });
      ctx.scanner.sigs = JSON.parse(fs.readFileSync(ctx.sigFile, "utf8"));  // the live scanner must follow the rollback
    }
    ctx.journal.append({ type: "halt", cycle: st.cycle, reason: halt, revertedTo: good ?? null }, ctx.keys);
  }

  if (!halt) {   // seal this cycle: a verified state the breaker can return to
    st.lastGoodSeq = ++st.seq;
    ctx.archive.snapshot(st.lastGoodSeq, { wikiDir: ctx.wikiDir, files: [ctx.sigFile] });
  }
  st.history.push(rec);
  ctx.journal.append({ type: "cycle", ...rec, sealed: halt ? null : st.lastGoodSeq }, ctx.keys);
  new Wiki(ctx.wikiDir).exportGraphJson(P(ctx.root, "state/graph.json"));
  saveState(ctx, st);
  return { cycle: st.cycle, before, after, rec, results, halted: st.halted, haltReason: st.haltReason, focus };
}

export function runCycles(ctx, n) {
  const out = [];
  for (let i = 0; i < n; i++) { const r = runCycle(ctx); out.push(r); if (r.halted) break; }
  return out;
}
