// objective.js — the scalar the loop maximizes, and the one thing it may not edit.
// Weights come from om-arch frontmatter and sit inside a protected namespace.
import { routerScores, memoryScores, securityScores, securityFitness, commerceScores } from "./kernel.js";
import { sliceSuites } from "./evals.js";
import { mean } from "./util.js";

export const SUITES = ["router", "memory", "security", "commerce"];

export function evaluate(theta, suites, scanner, slice = "train") {
  const s = sliceSuites(suites, slice);
  const perTask = {
    router: routerScores(theta, s.router),
    memory: memoryScores(theta, s.memory),
    security: securityScores(theta, s.security, scanner),
    commerce: commerceScores(theta, s.commerce),
  };
  const sec = securityFitness(perTask.security);
  const scores = {
    router: +mean(perTask.router.map(x => x.score)).toFixed(6),
    memory: +mean(perTask.memory.map(x => x.score)).toFixed(6),
    security: sec.fitness,
    commerce: +mean(perTask.commerce.map(x => x.score)).toFixed(6),
  };
  const w = { router: theta["om-arch.wRouter"], memory: theta["om-arch.wMemory"],
              security: theta["om-arch.wSecurity"], commerce: theta["om-arch.wCommerce"] };
  const tot = SUITES.reduce((a, k) => a + w[k], 0) || 1;
  const J = +(SUITES.reduce((a, k) => a + w[k] * scores[k], 0) / tot).toFixed(6);
  const cost = +mean(perTask.router.map(x => x.cost)).toFixed(6);
  const lat = +mean(perTask.router.map(x => x.lat)).toFixed(6);
  return { J, scores, perTask, security: sec, cost, latency: lat, slice, n: Object.fromEntries(SUITES.map(k => [k, s[k].length])) };
}
