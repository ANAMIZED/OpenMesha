// optimizer.js — (1+1)-ES over θ, where θ is whatever the Knowledge Galaxy
// declares writable. The optimizer never hardcodes a parameter list: it reads
// the frontmatter, so adding a governed param to a page is enough to put it
// under search. That is the concrete sense in which the wiki is a control surface.
import fs from "node:fs";
import { makeRng, clamp } from "./util.js";
import { evaluate } from "./objective.js";

export function thetaSpec(wiki) {
  const dims = [];
  for (const p of Object.values(wiki.pages)) {
    for (const [k, v] of Object.entries(p.params || {})) {
      const b = (p.bounds || {})[k];
      if (!b) continue;
      dims.push({
        slug: p.slug, key: k, full: p.slug + "." + k, lo: b[0], hi: b[1], value: v,
        int: (p.ints || []).includes(k), behavioral: (p.behavioral || []).includes(k),
        meta: (p.meta || []).includes(k), locked: wiki.isProtected(p.slug, k), evals: p.evals || [],
      });
    }
  }
  return dims;
}

const denorm = (d, n) => { const v = d.lo + clamp(n, 0, 1) * (d.hi - d.lo); return d.int ? Math.round(v) : +v.toFixed(6); };
const norm = (d, v) => (d.hi === d.lo ? 0 : (v - d.lo) / (d.hi - d.lo));

export class Optimizer {
  constructor(stateFile) {
    this.file = stateFile;
    this.s = fs.existsSync(stateFile) ? JSON.parse(fs.readFileSync(stateFile, "utf8"))
      : { sigma: null, window: [], trials: 0, accepts: 0 };
  }
  save() { fs.writeFileSync(this.file, JSON.stringify(this.s, null, 1)); }
  sigma(theta) { if (this.s.sigma == null) this.s.sigma = theta["rsi.sigma0"]; return this.s.sigma; }
  rate() { return this.s.window.length ? this.s.window.reduce((a, b) => a + b, 0) / this.s.window.length : 0; }

  propose(wiki, rng, { meta = false } = {}) {
    const theta = wiki.theta();
    const dims = thetaSpec(wiki).filter(d => !d.locked && (meta ? d.meta : !d.meta));
    if (!dims.length) return [];
    const n = meta ? 1 : Math.max(1, Math.min(dims.length, Math.round(theta["rsi.dims"])));
    const pool = [...dims];
    const picked = [];
    for (let i = 0; i < n && pool.length; i++) picked.push(pool.splice(rng.int(pool.length), 1)[0]);
    const sg = this.sigma(theta);
    const ops = [];
    for (const d of picked) {
      const v = denorm(d, norm(d, d.value) + rng.gauss() * sg);
      if (v !== d.value) ops.push({ kind: "param", slug: d.slug, key: d.key, value: v, from: d.value, meta: d.meta, behavioral: d.behavioral });
    }
    return ops;
  }
  // 1/5th success rule. successTarget / expandRate / shrinkRate are themselves
  // governed params — this is the line the meta-canary has to protect.
  // outcome ∈ accepted | rejected | noop.
  // The no-op case matters for discrete policies: a perturbation that does not
  // change a single argmax measures ΔJ = 0 exactly. Counting that as a failed
  // trial makes the 1/5th rule shrink σ, which produces smaller steps, which
  // produce more no-ops — a death spiral that looks like convergence. A no-op is
  // evidence that the step is too small, so it widens σ and does not enter the
  // acceptance window at all.
  update(theta, outcome) {
    const accepted = outcome === "accepted";
    if (outcome === "noop") {
      this.s.noops = (this.s.noops || 0) + 1;
      this.s.sigma = +clamp(this.sigma(theta) * theta["rsi.expandRate"], 0.05, 0.5).toFixed(6);
      this.save();
      return { sigma: this.s.sigma, rate: +this.rate().toFixed(3), outcome };
    }
    this.s.trials++; if (accepted) this.s.accepts++;
    this.s.window.push(accepted ? 1 : 0);
    if (this.s.window.length > 10) this.s.window.shift();
    const r = this.rate();
    const f = r > theta["rsi.successTarget"] ? theta["rsi.expandRate"] : theta["rsi.shrinkRate"];
    this.s.sigma = +clamp(this.sigma(theta) * f, 0.05, 0.5).toFixed(6);
    this.s.sinceLanding = accepted ? 0 : (this.s.sinceLanding || 0) + 1;
    let restarted = false;
    if (this.s.sinceLanding >= 12) {   // ES restart: σ collapse on a rugged landscape is stagnation, not convergence
      this.s.sigma = theta["rsi.sigma0"]; this.s.sinceLanding = 0; this.s.restarts = (this.s.restarts || 0) + 1; restarted = true;
    }
    this.save();
    return { sigma: this.s.sigma, rate: +r.toFixed(3), outcome, restarted };
  }
}

// Replay used by the meta-canary: run a short search from the current incumbent
// under a given meta setting and report the best training J reached. Meta params
// have no immediate effect on J, so this is the only honest way to test them.
export function esReplay(theta0, dims, suites, scanner, { seed, steps = 8, meta }) {
  const rng = makeRng(seed);
  const theta = { ...theta0 };
  let sigma = meta.sigma0, best = evaluate(theta, suites, scanner, "train").J;
  const win = [];
  const searchable = dims.filter(d => !d.locked && !d.meta);
  for (let i = 0; i < steps; i++) {
    const cand = { ...theta };
    const n = Math.max(1, Math.min(searchable.length, Math.round(meta.dims)));
    const pool = [...searchable];
    for (let j = 0; j < n && pool.length; j++) {
      const d = pool.splice(rng.int(pool.length), 1)[0];
      cand[d.full] = denorm(d, norm(d, cand[d.full]) + rng.gauss() * sigma);
    }
    const J = evaluate(cand, suites, scanner, "train").J;
    const acc = J > best;
    if (acc) { best = J; for (const k of Object.keys(cand)) theta[k] = cand[k]; }
    win.push(acc ? 1 : 0); if (win.length > 10) win.shift();
    const r = win.reduce((a, b) => a + b, 0) / win.length;
    sigma = clamp(sigma * (r > meta.successTarget ? meta.expandRate : meta.shrinkRate), 0.01, 0.5);
  }
  return best;
}
