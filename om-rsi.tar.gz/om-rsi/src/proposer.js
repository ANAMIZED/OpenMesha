// proposer.js — the improvement agent. Its distinguishing property is that it
// has NO hardcoded knowledge of the system: it decides what to work on by
// reading the Knowledge Galaxy's frontmatter and its own journalled history,
// and it grounds every prose claim in retrieved sources. Swap the template
// synthesis below for a model call and nothing else in the pipeline changes.
// WIRE: LLM synthesis (claim drafting) · NLI entailment · GEPA-style reflection.
import { thetaSpec } from "./optimizer.js";
import { SUITES } from "./objective.js";

// Read the self-model to choose a focus: the suite furthest below its own best.
export function selectFocus(wiki, history, rng) {
  const best = {};
  for (const h of history) for (const s of SUITES)
    if (h.scores?.[s] !== undefined) best[s] = Math.max(best[s] ?? 0, h.scores[s]);
  const cur = history.length ? history[history.length - 1].scores : null;
  if (!cur) return null;
  // Priority blends "lost ground since our best" with "room left above us".
  // Gap alone locks the focus onto a suite whose best was a fluke and can never
  // be recovered, which is a real failure mode: the loop stares at a 0.003 gap
  // in a saturated suite while a 0.09 headroom sits untouched elsewhere.
  const gaps = SUITES.map(s => ({ suite: s, gap: Math.max(0, (best[s] ?? cur[s]) - cur[s]), score: cur[s] }))
    .map(g => ({ ...g, priority: g.gap + 0.5 * (1 - g.score) }))
    .sort((a, b) => b.priority - a.priority);
  const target = gaps[0].suite;
  const pages = Object.values(wiki.pages).filter(p => (p.evals || []).includes(target));
  return pages.length ? { suite: target, slug: rng.pick(pages).slug } : null;
}

// Bias the ES toward the focus page's dims when one is identified; otherwise
// fall back to the optimizer's uniform proposal.
export function focusedProposal(wiki, optimizer, rng, focus) {
  const ops = optimizer.propose(wiki, rng)
    // Read the self-model: a page with no `evals` declares that nothing measures
    // it, so perturbing it can only ever produce ΔJ = 0. Spend the budget on
    // coordinates the objective can actually see.
    .filter(o => ((wiki.page(o.slug).evals || []).length > 0));
  if (!focus) return ops;
  const dims = thetaSpec(wiki).filter(d => !d.locked && !d.meta && d.slug === focus.slug);
  if (!dims.length || rng() < 0.35) return ops;
  const d = rng.pick(dims);
  const theta = wiki.theta();
  const sg = optimizer.sigma(theta);
  const n = (d.value - d.lo) / (d.hi - d.lo) + rng.gauss() * sg;
  const v0 = d.lo + Math.max(0, Math.min(1, n)) * (d.hi - d.lo);
  const value = d.int ? Math.round(v0) : +v0.toFixed(6);
  return value === d.value ? ops : [{ kind: "param", slug: d.slug, key: d.key, value, from: d.value, behavioral: d.behavioral, meta: false }];
}

const f6 = (x) => Number(x).toFixed(6);

// The cycle record, written back as an append-only source. This is the step that
// makes the loop recursive rather than merely self-tuning: next cycle's proposer
// retrieves this, and its numbers are what later prose claims are checked against.
export function telemetryNote(rec) {
  const lines = [
    "Cycle telemetry record " + rec.cycle,
    "training J " + f6(rec.trainJ) + " and holdout J " + f6(rec.holdoutJ) + " measured on disjoint slices.",
    "suite scores router " + f6(rec.scores.router) + " memory " + f6(rec.scores.memory) +
      " security " + f6(rec.scores.security) + " commerce " + f6(rec.scores.commerce) + ".",
    "step size sigma " + f6(rec.sigma) + " with acceptance rate " + f6(rec.rate) + " over the recent window.",
    "landed " + rec.landed + " changes, rejected " + rec.rejected + ", queued " + rec.queued + " for human authorization.",
    "security catch rate " + f6(rec.catchRate) + " with false positive rate " + f6(rec.fp) + " and " + rec.signatures + " active signatures.",
  ];
  return { title: "Cycle telemetry record " + rec.cycle, text: lines.join("\n") };
}

// Compose a grounded claim: a method fragment recombined from a retrieved
// external note, plus the measurement it explains. Must clear entailment against
// the EXTERNAL source, numeral grounding against the telemetry note, and the
// verbatim-span guard — so it cannot be a quotation and cannot invent numbers.
export function proseProposal(wiki, sources, rec, selfSource, focus, rng) {
  const query = (focus ? focus.suite + " " + focus.slug + " " : "") +
    "step size acceptance holdout overfitting ranking exploration price signature";
  const th = wiki.theta();
  const hits = sources.retrieve(query, { topK: Math.round(th["rki.topKSources"]), selfDecay: th["rki.selfDecay"], groundingOnly: true });
  const ext = hits.find(h => h.origin === "external");
  const self = selfSource;   // the record this cycle just wrote — not something to go looking for
  if (!ext || !self) return null;

  // Recombine: two fragments from different parts of the note, plus the
  // measurement they explain. Strip markdown headings first — a heading is not a
  // sentence, and letting one through produces claims that begin mid-title.
  const clean = ext.text.split("\n").filter(l => !l.trim().startsWith("#")).join(" ");
  const sents = clean.split(/(?<=[a-z0-9)])\.\s+(?=[A-Z])/).map(x => x.trim().replace(/\.$/, ""))
    .filter(x => x.split(/\s+/).length >= 10);
  if (sents.length < 2) return null;
  const i = rng.int(sents.length);
  let j = rng.int(sents.length); if (j === i) j = (i + 1) % sents.length;
  const frag = (str, start, n) => str.split(/\s+/).slice(start, start + n).join(" ").replace(/[.,;:]$/, "");
  const method = frag(sents[i], 0, 7 + rng.int(5)) + ", and " + frag(sents[j], rng.int(3), 7 + rng.int(5)).toLowerCase();
  const slug = focus?.slug || "learning";
  const text = "Method note — " + method + ". Measured this cycle: training J " + f6(rec.trainJ) +
    " against holdout J " + f6(rec.holdoutJ) + ", with sigma " + f6(rec.sigma) + " at acceptance " + f6(rec.rate) + ".";
  return { kind: "prose", slug, text, citations: [ext.hash, self.hash], tag: "Cycle " + rec.cycle };
}

// Occasionally the loop wants something it cannot verify. It must queue, not act.
export function tierCProposal(rng, cycle) {
  if (rng() > 0.25) return null;
  const wants = [
    { description: "purchase an external threat-intel feed to widen the adversarial corpus", amount: 1500 },
    { description: "pay an outcome fee on a verified kernel win", amount: 240 },
    { description: "wire a deposit to the metered payments rail", amount: 5000 },
  ];
  const w = rng.pick(wants);
  return { kind: "action", ...w, cycle };
}
