// sources.js — RKI: append-only, content-hashed, scanned-on-ingest evidence store.
// Retrieval down-weights self-authored material by generation, because a loop
// that cites itself converges on its own priors instead of on the world.
import fs from "node:fs";
import { sha256, tokenize } from "./util.js";

const STOP = new Set(["the","a","an","of","to","and","in","is","are","for","on","by","with","that","this","it","as","be","at","or","from","was","were","its","into","than","then","so","not"]);
const terms = (s) => tokenize(s).filter(w => !STOP.has(w));

export class Sources {
  constructor(file, scanner) {
    this.file = file; this.scanner = scanner;
    if (!fs.existsSync(file)) fs.writeFileSync(file, "");
  }
  all() { const t = fs.readFileSync(this.file, "utf8").trim(); return t ? t.split("\n").map(l => JSON.parse(l)) : []; }
  citable() { return this.all().filter(s => s.citable); }
  get(hash) { return this.all().find(s => s.hash === hash) || null; }

  // L1 runs BEFORE storage. Flagged text is kept (append-only, nothing is dropped)
  // but marked non-citable, so poisoned input can never become evidence.
  // grounding: may this source be used to ground a claim's method, and therefore
  // count in the external-ratio denominator? Measurements and raw attack strings
  // are citable (a claim may cite the record its numbers came from) but they are
  // not grounding evidence and must not dilute the ratio.
  ingest({ title, text, type = "note", origin = "external", generation = 0, grounding = null }) {
    const verdict = this.scanner.scanIngest(text, origin === "self" ? "loop" : "external");
    const hash = sha256(title + "\u0000" + text);
    const existing = this.get(hash);
    if (existing) return existing;
    const isGrounding = grounding === null ? !["telemetry", "evidence"].includes(type) : !!grounding;
    const rec = { hash, title, text, type, origin, generation, grounding: isGrounding, ts: Date.now(),
      scan: { verdict: verdict.verdict, findings: verdict.findings.length },
      quarantined: verdict.verdict === "blocked", citable: verdict.verdict !== "blocked" };
    fs.appendFileSync(this.file, JSON.stringify(rec) + "\n");
    return rec;
  }

  retrieve(query, { topK = 5, selfDecay = 0.6, groundingOnly = false } = {}) {
    const docs = groundingOnly ? this.grounded() : this.citable();
    if (!docs.length) return [];
    const df = {};
    const docTerms = docs.map(d => { const t = terms(d.title + " " + d.text); const set = new Set(t);
      for (const w of set) df[w] = (df[w] || 0) + 1; return t; });
    const idf = (w) => Math.log(1 + docs.length / (1 + (df[w] || 0)));
    const qt = terms(query);
    const scored = docs.map((d, i) => {
      const tf = {}; for (const w of docTerms[i]) tf[w] = (tf[w] || 0) + 1;
      let dot = 0; for (const w of qt) if (tf[w]) dot += (1 + Math.log(tf[w])) * idf(w);
      const norm = Math.sqrt(docTerms[i].length) || 1;
      const decay = d.origin === "self" ? Math.pow(selfDecay, (d.generation || 0) + 1) : 1;
      return { ...d, relevance: +(dot / norm * decay).toFixed(6) };
    });
    return scored.sort((a, b) => b.relevance - a.relevance).slice(0, topK);
  }

  grounded() { return this.citable().filter(s => s.grounding); }
  externalRatio() {
    const c = this.grounded();
    if (!c.length) return 1;
    return +(c.filter(s => s.origin === "external").length / c.length).toFixed(4);
  }
  stats() {
    const a = this.all();
    const g = this.grounded();
    return { total: a.length, citable: a.filter(s => s.citable).length,
             quarantined: a.filter(s => s.quarantined).length,
             grounding: g.length, groundingExternal: g.filter(s => s.origin === "external").length,
             records: a.filter(s => s.citable && !s.grounding).length,
             externalRatio: this.externalRatio() };
  }
  loadDir(dir) {
    if (!fs.existsSync(dir)) return 0;
    let n = 0;
    for (const f of fs.readdirSync(dir).filter(x => x.endsWith(".md"))) {
      const text = fs.readFileSync(dir + "/" + f, "utf8");
      const title = (text.split("\n")[0] || f).replace(/^#\s*/, "").trim();
      const before = this.all().length;
      this.ingest({ title, text, type: "external-note", origin: "external" });
      if (this.all().length > before) n++;
    }
    return n;
  }
}
