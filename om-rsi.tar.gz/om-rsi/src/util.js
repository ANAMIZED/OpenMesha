// util.js — hashing, signatures, seeded PRNG, distributions, stats. Node builtins only.
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";

// BROWSER-REPLACE-START sha256
export const sha256 = (s) => crypto.createHash("sha256").update(String(s)).digest("hex");
// BROWSER-REPLACE-END sha256
export const clamp = (x, a, b) => Math.max(a, Math.min(b, x));

// Deterministic stringify (sorted keys) so hashes/signatures are stable.
export function stableStringify(v) {
  if (v === null || typeof v !== "object") return JSON.stringify(v);
  if (Array.isArray(v)) return "[" + v.map(stableStringify).join(",") + "]";
  return "{" + Object.keys(v).sort().map(k => JSON.stringify(k) + ":" + stableStringify(v[k])).join(",") + "}";
}

// xorshift32 PRNG — every stochastic step in the system draws from a seeded rng.
export function makeRng(seed) {
  let s = (seed >>> 0) || 0x2f6e2b1;
  const next = () => { s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; };
  let spare = null;
  const rng = () => next();
  rng.int = (n) => Math.floor(next() * n);
  rng.pick = (arr) => arr[rng.int(arr.length)];
  rng.range = (a, b) => a + (b - a) * next();
  rng.gauss = () => {
    if (spare !== null) { const v = spare; spare = null; return v; }
    let u = 0, v = 0; while (u === 0) u = next(); while (v === 0) v = next();
    const m = Math.sqrt(-2 * Math.log(u)), th = 2 * Math.PI * v;
    spare = m * Math.sin(th); return m * Math.cos(th);
  };
  rng.state = () => s;
  return rng;
}

// Marsaglia–Tsang gamma, then Beta — real Thompson sampling needs real Beta draws.
export function gammaSample(rng, k) {
  if (k < 1) { const u = rng(); return gammaSample(rng, k + 1) * Math.pow(u, 1 / k); }
  const d = k - 1 / 3, c = 1 / Math.sqrt(9 * d);
  for (;;) {
    let x, v;
    do { x = rng.gauss(); v = 1 + c * x; } while (v <= 0);
    v = v * v * v;
    const u = rng();
    if (u < 1 - 0.0331 * x * x * x * x) return d * v;
    if (Math.log(u) < 0.5 * x * x + d * (1 - v + Math.log(v))) return d * v;
  }
}
export const betaSample = (rng, a, b) => { const x = gammaSample(rng, a), y = gammaSample(rng, b); return x / (x + y); };

export const mean = (a) => a.length ? a.reduce((x, y) => x + y, 0) / a.length : 0;
export const stdev = (a) => { const m = mean(a); return Math.sqrt(mean(a.map(x => (x - m) ** 2))); };

// Percentile-bootstrap CI on mean(a) - mean(b). Seeded ⇒ deterministic significance tests.
export function bootstrapDiff(a, b, rng, iters = 800, alpha = 0.05) {
  if (!a.length || !b.length) return { diff: 0, lo: 0, hi: 0 };
  const diffs = [];
  for (let i = 0; i < iters; i++) {
    let sa = 0, sb = 0;
    for (let j = 0; j < a.length; j++) sa += a[rng.int(a.length)];
    for (let j = 0; j < b.length; j++) sb += b[rng.int(b.length)];
    diffs.push(sa / a.length - sb / b.length);
  }
  diffs.sort((x, y) => x - y);
  const lo = diffs[Math.floor(alpha / 2 * iters)], hi = diffs[Math.floor((1 - alpha / 2) * iters)];
  return { diff: mean(a) - mean(b), lo, hi };
}

// ed25519 identity for the verifier (and a separate human key for Tier C).
// BROWSER-REPLACE-START keys
export function loadOrCreateKeys(dir, name) {
  fs.mkdirSync(dir, { recursive: true });
  const priv = path.join(dir, name + ".priv.pem"), pub = path.join(dir, name + ".pub.pem");
  if (!fs.existsSync(priv)) {
    const { publicKey, privateKey } = crypto.generateKeyPairSync("ed25519");
    fs.writeFileSync(priv, privateKey.export({ type: "pkcs8", format: "pem" }));
    fs.writeFileSync(pub, publicKey.export({ type: "spki", format: "pem" }));
  }
  return {
    sign: (data) => crypto.sign(null, Buffer.from(data), fs.readFileSync(priv)).toString("base64"),
    verify: (data, sig) => { try { return crypto.verify(null, Buffer.from(data), fs.readFileSync(pub), Buffer.from(sig, "base64")); } catch { return false; } },
    pubPem: () => fs.readFileSync(pub, "utf8"),
  };
}
// BROWSER-REPLACE-END keys

export const nowIso = () => new Date().toISOString();
export const tokenize = (s) => String(s).toLowerCase().replace(/[^a-z0-9$.]+/g, " ").split(" ").filter(w => w.length > 1);
export const numbersIn = (s) => (String(s).match(/-?\d+(?:\.\d+)?/g) || []).map(x => x.replace(/\.0+$/, ""));
