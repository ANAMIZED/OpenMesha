// verifier.js — the machine that replaced the human tap.
//
// Tier assignment is by VERIFIABILITY, not by how serious a change feels:
//   REJECT  protected namespace — no path exists, not even a human one, in-loop
//   A       deterministic scalar effect → direct measurement
//   B       distributional effect → paired bootstrap on a reserved canary slice
//   META    no immediate effect on J → replayed search runs under both settings
//   C       no fast objective verifier (money / irreversible) → human token
//
// Everything is measured on a SANDBOX COPY of the galaxy first; only a passing
// sandbox is committed, and every commit is archived, hashed and signed.
import fs from "node:fs";
import { Wiki } from "./wiki.js";
import { Scanner } from "./scan.js";
import { evaluate } from "./objective.js";
import { esReplay, thetaSpec } from "./optimizer.js";
import { bootstrapDiff, makeRng, numbersIn, tokenize, sha256, stableStringify } from "./util.js";

const STOP = new Set(["the","a","an","of","to","and","in","is","are","for","on","by","with","that","this","it","as","be","at","or","from","was","were","its","into","than","then","so","not","we","our","has","have","been","after","before","per","over","under","when","which","their","them","also","now","only","more","most","less","new"]);
const content = (s) => [...new Set(tokenize(s).filter(w => !STOP.has(w) && !/^\d+(\.\d+)?$/.test(w)))];

// Longest run of consecutive words shared by two texts — a cheap plagiarism /
// degenerate-copy detector, used to keep "entailment" from rewarding quotation.
export function longestSharedSpan(a, b) {
  const A = tokenize(a), B = tokenize(b);
  if (!A.length || !B.length) return 0;
  let best = 0; let prev = new Array(B.length + 1).fill(0);
  for (let i = 1; i <= A.length; i++) {
    const cur = new Array(B.length + 1).fill(0);
    for (let j = 1; j <= B.length; j++)
      if (A[i - 1] === B[j - 1]) { cur[j] = prev[j - 1] + 1; if (cur[j] > best) best = cur[j]; }
    prev = cur;
  }
  return best;
}

export const ok = (name, pass, detail) => ({ name, ok: !!pass, detail });

export class Verifier {
  constructor(ctx) {
    this.ctx = ctx;
    this.ratchetFile = ctx.ratchetFile || "state/ratchet.json"; // {wikiDir, sandboxDir, sigFile, sandboxSigFile, scanner, sources, suites, journal, keys, humanKeys, archive}
  }
  // Monotone safety ratchet: security fitness may never fall below the best it
  // has ever reached (minus epsilon), on top of the protected absolute floor.
  // A static floor alone is not enough — once the loop hardens the scanner, the
  // floor stops binding and nothing stops it from trading that gain away later.
  ratchet() { try { return JSON.parse(fs.readFileSync(this.ratchetFile, "utf8")); } catch { return { securityFitness: 0 }; } }
  bumpRatchet(fitness) {
    const r = this.ratchet();
    if (fitness > r.securityFitness) { r.securityFitness = fitness; fs.writeFileSync(this.ratchetFile, JSON.stringify(r, null, 1)); }
    return r;
  }
  _sandbox() {
    const { wikiDir, sandboxDir, sigFile, sandboxSigFile } = this.ctx;
    fs.rmSync(sandboxDir, { recursive: true, force: true });
    fs.cpSync(wikiDir, sandboxDir, { recursive: true });
    fs.copyFileSync(sigFile, sandboxSigFile);
    return { wiki: new Wiki(sandboxDir), scanner: new Scanner(sandboxSigFile) };
  }
  baseline(wiki = new Wiki(this.ctx.wikiDir), scanner = this.ctx.scanner) {
    const t = wiki.theta();
    return { theta: t, train: evaluate(t, this.ctx.suites, scanner, "train"),
             holdout: evaluate(t, this.ctx.suites, scanner, "holdout"),
             all: evaluate(t, this.ctx.suites, scanner, "all") };
  }
  tierOf(op, wiki) {
    if (op.kind === "action") return "C";
    if (op.kind === "prose" || op.kind === "signature" || op.kind === "signature-prune") return "A";
    if (wiki.isProtected(op.slug, op.key)) return "REJECT";
    const spec = thetaSpec(wiki).find(d => d.full === op.slug + "." + op.key);
    if (spec?.meta) return "META";
    return spec?.behavioral ? "B" : "A";
  }

  // ── Tier A / B parameter change ───────────────────────────────────────────
  checkParam(op, wiki, base, tier) {
    const checks = [];
    const th = base.theta;
    const eps = th["rsi.holdoutEpsilon"], floor = th["security.floor"];
    const b = wiki.boundsOf(op.slug, op.key);
    checks.push(ok("bounds", b && op.value >= b[0] && op.value <= b[1], op.slug + "." + op.key + "=" + op.value + " ∈ [" + b + "]"));
    checks.push(ok("protection", !wiki.isProtected(op.slug, op.key), "not in a protected namespace"));
    if (checks.some(c => !c.ok)) return { ok: false, checks };

    const sb = this._sandbox();
    try { sb.wiki.setParam(op.slug, op.key, op.value); } catch (e) { checks.push(ok("apply", false, e.message)); return { ok: false, checks }; }
    const after = this.baseline(sb.wiki, sb.scanner);

    const guard = Math.max(floor, this.ratchet().securityFitness - eps);
    checks.push(ok("safety-floor", after.all.security.fitness >= guard,
      "security fitness " + after.all.security.fitness.toFixed(4) + " ≥ guard " + guard.toFixed(4) + " (floor " + floor + ", ratchet " + this.ratchet().securityFitness.toFixed(4) + ")"));
    checks.push(ok("train-improves", after.train.J > base.train.J,
      "ΔJ_train " + (after.train.J - base.train.J).toFixed(6)));
    checks.push(ok("holdout-non-regression", after.holdout.J >= base.holdout.J - eps,
      "ΔJ_holdout " + (after.holdout.J - base.holdout.J).toFixed(6) + " ≥ −" + eps));

    const blast = wiki.blastRadius(op.slug);
    let blastOk = true, worst = "";
    for (const s of blast.evals) {
      const d = after.train.scores[s] - base.train.scores[s];
      if (d < -eps) { blastOk = false; worst = s + " " + d.toFixed(6); }
    }
    checks.push(ok("blast-radius", blastOk, "suites [" + blast.evals.join(",") + "]" + (blastOk ? " held" : " regressed: " + worst)));

    if (tier === "B") {
      const rng = makeRng(1234567);
      const bc = evaluate(base.theta, this.ctx.suites, this.ctx.scanner, "canary");
      const ac = evaluate(after.theta, this.ctx.suites, sb.scanner, "canary");
      const frac = th["verifier.canaryFrac"], alpha = th["verifier.canaryAlpha"];
      let anyUp = false, anyDown = false, detail = [];
      for (const s of blast.evals) {
        const bm = new Map(bc.perTask[s].map(x => [x.id, x.score]));
        const d = [];
        for (const x of ac.perTask[s]) if (bm.has(x.id)) d.push(x.score - bm.get(x.id));
        const keep = frac >= 1 ? d : d.filter(() => rng() < frac);
        const sample = keep.length >= 12 ? keep : d;
        if (!sample.length) continue;
        const ci = bootstrapDiff(sample, sample.map(() => 0), rng, 800, alpha);
        if (ci.lo > 0) anyUp = true;
        if (ci.hi < 0) anyDown = true;
        detail.push(s + " n=" + sample.length + " Δ" + ci.diff.toFixed(5) + " [" + ci.lo.toFixed(5) + "," + ci.hi.toFixed(5) + "]");
      }
      checks.push(ok("canary-significant", anyUp && !anyDown, detail.join(" · ")));
    }
    return { ok: checks.every(c => c.ok), checks, after, delta: +(after.train.J - base.train.J).toFixed(9) };
  }

  // ── META: a meta-parameter cannot be judged by one trial, so replay search ──
  checkMeta(op, wiki, base) {
    const checks = [];
    const b = wiki.boundsOf(op.slug, op.key);
    checks.push(ok("bounds", b && op.value >= b[0] && op.value <= b[1], op.slug + "." + op.key + "=" + op.value));
    checks.push(ok("protection", !wiki.isProtected(op.slug, op.key), "not protected"));
    if (checks.some(c => !c.ok)) return { ok: false, checks };

    const dims = thetaSpec(wiki);
    const metaOf = (t) => ({ sigma0: t["rsi.sigma0"], expandRate: t["rsi.expandRate"], shrinkRate: t["rsi.shrinkRate"], successTarget: t["rsi.successTarget"], dims: t["rsi.dims"] });
    const oldMeta = metaOf(base.theta), newMeta = metaOf({ ...base.theta, [op.slug + "." + op.key]: op.value });
    const A = [], B = [];
    for (let s = 0; s < 6; s++) {
      A.push(esReplay(base.theta, dims, this.ctx.suites, this.ctx.scanner, { seed: 5000 + s * 31, steps: 8, meta: newMeta }));
      B.push(esReplay(base.theta, dims, this.ctx.suites, this.ctx.scanner, { seed: 5000 + s * 31, steps: 8, meta: oldMeta }));
    }
    const rng = makeRng(778899);
    const deltas = A.map((x, i) => x - B[i]);
    const ci = bootstrapDiff(deltas, deltas.map(() => 0), rng, 800, base.theta["verifier.canaryAlpha"]);
    checks.push(ok("meta-canary", ci.lo > 0,
      "replayed 6 paired searches · mean Δbest-J " + ci.diff.toFixed(6) + " CI[" + ci.lo.toFixed(6) + "," + ci.hi.toFixed(6) + "]"));
    return { ok: checks.every(c => c.ok), checks };
  }

  // ── Prose: grounded, numerically faithful, non-contradictory ──────────────
  checkProse(op, wiki, base, { atProposal = true } = {}) {
    const checks = [];
    const th = base.theta;
    const cited = (op.citations || []).map(h => this.ctx.sources.get(h));
    checks.push(ok("citations-resolve", cited.length > 0 && cited.every(c => c && c.citable),
      cited.length + " citation(s), all citable"));
    if (!checks[0].ok) return { ok: false, checks };
    checks.push(ok("external-anchor", cited.some(c => c.origin === "external"),
      "at least one non-self source"));
    const ratio = this.ctx.sources.externalRatio();
    checks.push(ok("corpus-external-ratio", ratio >= th["rki.minExternalRatio"],
      "external share " + ratio + " ≥ floor " + th["rki.minExternalRatio"]));

    const l1 = this.ctx.scanner.scan(op.text);
    checks.push(ok("l1-clean", l1.findings.length === 0, l1.findings.length ? "flagged: " + l1.findings[0] : "clean"));

    // Coverage is measured against EXTERNAL sources only. If the loop's own
    // telemetry note counted, a claim could ground itself by quoting the record
    // it just wrote — coverage 1.0, evidence 0. Numerals are checked against all
    // citations, because measurements legitimately come from the loop's record.
    const ext = cited.filter(c => c.origin === "external");
    const pool = cited.map(c => c.title + " " + c.text).join(" ");
    const extPool = ext.map(c => c.title + " " + c.text).join(" ");
    const extTok = new Set(content(extPool));
    const claimTok = content(op.text);
    const cov = claimTok.length ? claimTok.filter(w => extTok.has(w)).length / claimTok.length : 0;
    checks.push(ok("entailment", cov >= th["verifier.entailmentThreshold"],
      "lexical coverage vs external sources " + cov.toFixed(3) + " ≥ " + th["verifier.entailmentThreshold"]));

    // Anti-degenerate guard: lexical coverage rewards quotation. Requiring the
    // claim to share no long verbatim span with any source forces recombination.
    let longest = 0, worstSrc = "";
    for (const c of cited) { const L = longestSharedSpan(op.text, c.text); if (L > longest) { longest = L; worstSrc = c.title; } }
    checks.push(ok("not-verbatim", longest < 12, "longest shared span " + longest + " words" + (longest >= 12 ? " from " + worstSrc : "")));

    if (atProposal) {   // a landed claim is by definition already on the page
      const dup = longestSharedSpan(op.text, wiki.page(op.slug).body);
      checks.push(ok("not-duplicate", dup < 12, "longest span shared with the page already " + dup + " words"));
    }

    const poolNums = new Set(numbersIn(pool));
    const missing = numbersIn(op.text).filter(n => !poolNums.has(n));
    checks.push(ok("numerals-grounded", missing.length === 0,
      missing.length ? "ungrounded: " + missing.join(",") : numbersIn(op.text).length + " numeral(s) all present in cited text"));

    const contra = [];
    for (const m of String(op.text).matchAll(/\b([a-z][a-z-]*)\.([a-zA-Z][a-zA-Z0-9]*)\s*(?:=|is|to)\s*(-?\d+(?:\.\d+)?)/g)) {
      const [, slug, key, val] = m;
      const live = th[slug + "." + key];
      if (live !== undefined && Math.abs(live - parseFloat(val)) > 1e-9) contra.push(slug + "." + key + " claimed " + val + " but live " + live);
    }
    checks.push(ok("no-contradiction", contra.length === 0, contra.length ? contra.join("; ") : "consistent with live frontmatter"));
    return { ok: checks.every(c => c.ok), checks };
  }

  // ── Signature: evidence-backed, and precision may never fall ──────────────
  checkSignature(op, wiki, base) {
    const checks = [];
    let valid = true; try { new RegExp(op.sig); } catch { valid = false; }
    checks.push(ok("regex-valid", valid, op.sig.slice(0, 60)));
    if (!valid) return { ok: false, checks };
    const sb = this._sandbox();
    sb.scanner.addSignatures([op.sig]);
    checks.push(ok("catches-evidence", sb.scanner.scan(op.evidence).findings.length >= Math.round(base.theta["security.blockAt"]),
      "bypass now caught"));
    const after = this.baseline(sb.wiki, sb.scanner);
    checks.push(ok("no-new-false-positives", after.all.security.fp <= base.all.security.fp,
      "FP " + base.all.security.fp.toFixed(4) + " → " + after.all.security.fp.toFixed(4)));
    checks.push(ok("catch-rate-improves", after.all.security.catchRate > base.all.security.catchRate,
      "catch " + base.all.security.catchRate.toFixed(4) + " → " + after.all.security.catchRate.toFixed(4)));
    const guard = Math.max(base.theta["security.floor"], this.ratchet().securityFitness - base.theta["rsi.holdoutEpsilon"]);
    checks.push(ok("safety-floor", after.all.security.fitness >= guard,
      "fitness " + after.all.security.fitness.toFixed(4) + " ≥ guard " + guard.toFixed(4)));
    return { ok: checks.every(c => c.ok), checks, after };
  }

  // Removing a rule is as consequential as adding one, so it faces the mirror
  // image of the same checks: recall may not fall, precision must actually rise.
  checkPrune(op, wiki, base) {
    const checks = [];
    const sb = this._sandbox();
    sb.scanner.removeSignatures([op.sig]);
    const after = this.baseline(sb.wiki, sb.scanner);
    checks.push(ok("catch-rate-held", after.all.security.catchRate >= base.all.security.catchRate,
      "catch " + base.all.security.catchRate.toFixed(4) + " → " + after.all.security.catchRate.toFixed(4)));
    checks.push(ok("false-positives-drop", after.all.security.fp < base.all.security.fp,
      "FP " + base.all.security.fp.toFixed(4) + " → " + after.all.security.fp.toFixed(4)));
    const guard = Math.max(base.theta["security.floor"], this.ratchet().securityFitness - base.theta["rsi.holdoutEpsilon"]);
    checks.push(ok("safety-floor", after.all.security.fitness >= guard, "fitness " + after.all.security.fitness.toFixed(4) + " ≥ guard " + guard.toFixed(4)));
    return { ok: checks.every(c => c.ok), checks, after };
  }

  // ── Orchestration: assess, then land / queue / reject, one op at a time ────
  process(ops, { cycle, nextSeq }) {
    const out = { landed: [], rejected: [], queued: [] };
    for (const op of ops) {
      const wiki = new Wiki(this.ctx.wikiDir);
      const base = this.baseline(wiki, this.ctx.scanner);
      const tier = this.tierOf(op, wiki);
      let res;
      if (tier === "REJECT") res = { ok: false, checks: [ok("protection", false, "protected namespace " + op.slug + "." + op.key + " — unreachable by the loop")] };
      else if (tier === "C") res = { ok: false, checks: [ok("verifier-exists", false, "no fast objective verifier — queued for a human token")] };
      else if (op.kind === "prose") res = this.checkProse(op, wiki, base);
      else if (op.kind === "signature") res = this.checkSignature(op, wiki, base);
      else if (op.kind === "signature-prune") res = this.checkPrune(op, wiki, base);
      else if (tier === "META") res = this.checkMeta(op, wiki, base);
      else res = this.checkParam(op, wiki, base, tier);

      const record = { cycle, tier, op, checks: res.checks, ok: res.ok, delta: res.delta ?? null };
      if (tier === "C") {
        const item = { ...op, id: sha256(stableStringify(op)).slice(0, 12), tier: "C", cycle, status: "awaiting-human-token" };
        this.ctx.journal.append({ type: "queue.tierC", item, checks: res.checks }, this.ctx.keys);
        out.queued.push(item);
        continue;
      }
      if (!res.ok) {
        this.ctx.journal.append({ type: "reject", ...record }, this.ctx.keys);
        out.rejected.push(record);
        continue;
      }
      // land: archive → sign+journal → apply
      const seq = nextSeq();
      this.ctx.archive.snapshot(seq, { wikiDir: this.ctx.wikiDir, files: [this.ctx.sigFile] });
      const metrics = res.after ? { trainJ: res.after.train.J, holdoutJ: res.after.holdout.J, scores: res.after.train.scores } : null;
      const entry = this.ctx.journal.append({ type: "land", seq, ...record, metrics }, this.ctx.keys);
      if (op.kind === "param") { const w = new Wiki(this.ctx.wikiDir); w.setParam(op.slug, op.key, op.value); }
      else if (op.kind === "prose") { const w = new Wiki(this.ctx.wikiDir); w.appendUpdate(op.slug, op.text, op.citations, op.tag || "Cycle"); }
      else if (op.kind === "signature") this.ctx.scanner.addSignatures([op.sig]);
      else if (op.kind === "signature-prune") this.ctx.scanner.removeSignatures([op.sig]);
      if (res.after) this.bumpRatchet(res.after.all.security.fitness);
      out.landed.push({ ...record, hash: entry.hash, metrics });
    }
    return out;
  }

  // Tier C never executes without a signed, unexpired human token.
  executeTierC(item, token) {
    const th = new Wiki(this.ctx.wikiDir).theta();
    const ttl = th["hotl.tokenTtlMinutes"] * 60000;
    if (!token || !token.sig || !token.issuedAt) return { ok: false, reason: "no token" };
    if (Date.now() - token.issuedAt > ttl) return { ok: false, reason: "token expired" };
    if (!this.ctx.humanKeys.verify(item.id, token.sig)) return { ok: false, reason: "bad human signature" };
    this.ctx.journal.append({ type: "execute.tierC", item, issuedAt: token.issuedAt }, this.ctx.keys);
    return { ok: true, executed: item.id };
  }
}
