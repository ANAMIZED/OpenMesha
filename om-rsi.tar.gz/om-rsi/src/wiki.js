// wiki.js — the Knowledge Galaxy as a CONTROL SURFACE, not a mirror.
// Design move that closes the recursion: governed parameters θ live in page
// frontmatter. The kernel READS θ from here each cycle; landed diffs CHANGE
// behavior next cycle. Pages are markdown with [[Wikilinks]]; the graph and
// blast-radius map are parsed from links, Obsidian-style.
//
// Frontmatter format (machine-perfect, no YAML ambiguity):
//   ---json
//   { "slug":..., "title":..., "sys":..., "params":{...}, "bounds":{...},
//     "behavioral":[...], "evals":[...], "invariants":[...] }
//   ---
//
// INVARIANTS enforced here:
//   I1  body is append-only — the only body mutation is appendUpdate()
//   I2  param changes must respect declared [lo,hi] bounds
//   I3  protected namespaces (declared on om-arch) never change autonomously
import fs from "node:fs";
import path from "node:path";
import { nowIso } from "./util.js";

const FM_OPEN = "---json", FM_CLOSE = "---";

export function parsePage(raw, file) {
  const lines = raw.split("\n");
  if (lines[0].trim() !== FM_OPEN) throw new Error("missing ---json frontmatter: " + file);
  let i = 1; const fmLines = [];
  while (i < lines.length && lines[i].trim() !== FM_CLOSE) { fmLines.push(lines[i]); i++; }
  const fm = JSON.parse(fmLines.join("\n"));
  const body = lines.slice(i + 1).join("\n");
  return { ...fm, body };
}
export function serializePage(p) {
  const { body, ...fm } = p;
  return FM_OPEN + "\n" + JSON.stringify(fm, null, 1) + "\n" + FM_CLOSE + "\n" + body;
}
export const wikilinks = (body) => [...String(body).matchAll(/\[\[([^\]|]+)(?:\|[^\]]*)?\]\]/g)].map(m => m[1].trim());

export class Wiki {
  constructor(dir) { this.dir = dir; this.reload(); }
  reload() {
    this.pages = {};
    for (const f of fs.readdirSync(this.dir).filter(x => x.endsWith(".md"))) {
      const p = parsePage(fs.readFileSync(path.join(this.dir, f), "utf8"), f);
      this.pages[p.slug] = p;
    }
    this.titleToSlug = {};
    for (const p of Object.values(this.pages)) this.titleToSlug[p.title] = p.slug;
  }
  page(slug) { const p = this.pages[slug]; if (!p) throw new Error("no page: " + slug); return p; }
  _write(p) { fs.writeFileSync(path.join(this.dir, p.slug + ".md"), serializePage(p)); }

  // Collected governed parameters: { "<slug>.<key>": value }
  theta() {
    const out = {};
    for (const p of Object.values(this.pages))
      for (const [k, v] of Object.entries(p.params || {})) out[p.slug + "." + k] = v;
    return out;
  }
  boundsOf(slug, key) { return (this.page(slug).bounds || {})[key] || null; }
  isBehavioral(slug, key) { return (this.page(slug).behavioral || []).includes(key); }
  protectedNamespaces() { return this.page("om-arch").protectedNamespaces || []; }
  isProtected(slug, key) {
    const full = slug + "." + key;
    return this.protectedNamespaces().some(ns => full === ns || full.startsWith(ns));
  }

  graph() {
    const nodes = Object.values(this.pages).map(p => ({ slug: p.slug, title: p.title, sys: p.sys, degree: 0 }));
    const bySlug = Object.fromEntries(nodes.map(n => [n.slug, n]));
    const edges = [];
    for (const p of Object.values(this.pages))
      for (const t of wikilinks(p.body)) {
        const to = this.titleToSlug[t];
        if (to && to !== p.slug) { edges.push({ from: p.slug, to }); bySlug[p.slug].degree++; bySlug[to].degree++; }
      }
    return { nodes, edges };
  }
  // Blast radius: evals of the page itself plus every page linked either direction.
  blastRadius(slug) {
    const g = this.graph();
    const near = new Set([slug]);
    for (const e of g.edges) { if (e.from === slug) near.add(e.to); if (e.to === slug) near.add(e.from); }
    const evals = new Set();
    for (const s of near) for (const ev of (this.pages[s]?.evals || [])) evals.add(ev);
    return { pages: [...near], evals: [...evals] };
  }

  // The ONLY body mutation in the codebase. Append-only by construction (I1).
  appendUpdate(slug, text, citations = [], tag = "Update") {
    const p = this.page(slug);
    const cite = citations.length ? " [cites: " + citations.map(h => h.slice(0, 10)).join(", ") + "]" : "";
    p.body += "\n\n**" + tag + " · " + nowIso() + "** — " + text + cite;
    this._write(p);
    return p;
  }
  // Param mutation — bounds-checked; protection is enforced by the gate/verifier
  // before this is ever called, and re-checked here as defense in depth (I2, I3).
  setParam(slug, key, value, { allowProtected = false } = {}) {
    const p = this.page(slug);
    if (!(key in (p.params || {}))) throw new Error("unknown param " + slug + "." + key);
    if (!allowProtected && this.isProtected(slug, key)) throw new Error("protected namespace: " + slug + "." + key);
    const b = this.boundsOf(slug, key);
    if (b && (value < b[0] || value > b[1])) throw new Error("out of bounds " + slug + "." + key + "=" + value + " ∉ [" + b + "]");
    const old = p.params[key];
    p.params[key] = value;
    this._write(p);
    return { old, value };
  }
  exportGraphJson(file) { fs.writeFileSync(file, JSON.stringify(this.graph(), null, 1)); }
}
