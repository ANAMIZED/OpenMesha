import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { execFileSync } from "node:child_process";
import { makeContext } from "../src/loop.js";

const REPO = path.resolve(import.meta.dirname, "..");

// Every test gets a throwaway universe: its own galaxy, journal, keys, archive.
export function tmpRoot() {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "om-rsi-"));
  fs.mkdirSync(path.join(root, "wiki"), { recursive: true });
  execFileSync("node", [path.join(REPO, "scripts/seed-wiki.js"), path.join(root, "wiki"), "--force"], { cwd: REPO });
  fs.cpSync(path.join(REPO, "seed_notes"), path.join(root, "seed_notes"), { recursive: true });
  return root;
}
export function ctxFor(root) { return makeContext(root); }
export const cleanup = (root) => fs.rmSync(root, { recursive: true, force: true });
