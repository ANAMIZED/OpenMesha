import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { tmpRoot, ctxFor, cleanup } from "./helpers.js";
import { Wiki } from "../src/wiki.js";
import { runCycle, runCycles, loadState } from "../src/loop.js";

test("loop: a cycle runs end to end and leaves a verifiable trail", () => {
  const root = tmpRoot(); const ctx = ctxFor(root);
  const r = runCycle(ctx);
  assert.equal(r.cycle, 1);
  assert.ok(r.rec.trainJ > 0 && r.rec.holdoutJ > 0);
  assert.equal(ctx.journal.verify(ctx.keys).ok, true);
  assert.ok(fs.existsSync(path.join(root, "state/graph.json")));
  assert.ok(ctx.sources.all().some(s => s.origin === "self"), "the cycle must write its record back as evidence");
  cleanup(root);
});

test("loop: best-so-far J ratchets and holdout does not diverge", () => {
  const root = tmpRoot(); const ctx = ctxFor(root);
  runCycles(ctx, 12);
  const h = loadState(ctx).history;
  assert.ok(h.length >= 10);
  let best = -Infinity;
  for (const x of h) { assert.ok(x.trainJ >= best - 1e-9, "best-so-far J went backwards"); best = Math.max(best, x.trainJ); }
  assert.ok(h[h.length - 1].trainJ > h[0].trainJ, "12 cycles produced no improvement at all");
  // Goodharting is train rising WHILE holdout falls. A widening gap on its own
  // is not evidence: the holdout slice starts easier here, so the gap begins
  // negative and closes as both curves rise together.
  const dTrain = h[h.length - 1].trainJ - h[0].trainJ, dHold = h[h.length - 1].holdoutJ - h[0].holdoutJ;
  assert.ok(dTrain > 0 && dHold >= -0.005, "train improved by " + dTrain.toFixed(4) + " while holdout moved " + dHold.toFixed(4) + " — Goodharting");
  cleanup(root);
});

test("loop: no protected parameter is ever written across a full run", () => {
  const root = tmpRoot(); const ctx = ctxFor(root);
  const before = new Wiki(ctx.wikiDir).theta();
  runCycles(ctx, 12);
  const after = new Wiki(ctx.wikiDir).theta();
  const w = new Wiki(ctx.wikiDir);
  for (const key of Object.keys(before)) {
    const [slug, k] = [key.slice(0, key.indexOf(".")), key.slice(key.indexOf(".") + 1)];
    if (w.isProtected(slug, k)) assert.equal(after[key], before[key], key + " moved");
  }
  const landed = ctx.journal.read().filter(e => e.core.type === "land" && e.core.op?.kind === "param");
  assert.ok(landed.every(e => !w.isProtected(e.core.op.slug, e.core.op.key)));
  cleanup(root);
});

test("loop: Tier C accumulates in the queue and never executes itself", () => {
  const root = tmpRoot(); const ctx = ctxFor(root);
  runCycles(ctx, 14);
  const st = loadState(ctx);
  assert.ok(st.tierC.length > 0, "no Tier C item was ever proposed — the escalation path is untested");
  assert.ok(st.tierC.every(q => q.status === "awaiting-human-token"));
  assert.equal(ctx.journal.read().filter(e => e.core.type === "execute.tierC").length, 0);
  assert.equal(ctx.journal.read().filter(e => e.core.type === "land" && e.core.op?.kind === "action").length, 0);
  cleanup(root);
});

test("breaker: a security collapse halts the loop and reverts to the last good generation", () => {
  const root = tmpRoot(); const ctx = ctxFor(root);
  runCycles(ctx, 6);
  const sigsBefore = JSON.parse(fs.readFileSync(ctx.sigFile, "utf8")).length;
  assert.ok(ctx.archive.list().length > 0, "nothing archived to revert to");
  fs.writeFileSync(ctx.sigFile, JSON.stringify([]));      // out-of-band corruption: the scanner is emptied
  ctx.scanner.sigs = [];
  const r = runCycle(ctx);
  assert.equal(r.halted, true);
  assert.match(r.haltReason, /below protected floor/);
  const sigsAfter = JSON.parse(fs.readFileSync(ctx.sigFile, "utf8")).length;
  assert.ok(sigsAfter >= sigsBefore - 2 && sigsAfter > 0, "signatures were not restored from the archive");
  assert.equal(runCycle(ctx).halted, true, "a halted loop must stay halted until a human resumes it");
  cleanup(root);
});

test("breaker: a broken journal chain halts the loop", () => {
  const root = tmpRoot(); const ctx = ctxFor(root);
  runCycles(ctx, 3);
  const rows = fs.readFileSync(ctx.journal.file, "utf8").trim().split("\n").map(JSON.parse);
  rows[1].core.tampered = true;
  fs.writeFileSync(ctx.journal.file, rows.map(r => JSON.stringify(r)).join("\n") + "\n");
  const r = runCycle(ctx);
  assert.equal(r.halted, true);
  assert.match(r.haltReason, /chain integrity/);
  cleanup(root);
});
